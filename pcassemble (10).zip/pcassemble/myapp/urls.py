

from django.urls import path
from .import views

urlpatterns = [
   path('login/',views.login),
   path('loginpost/',views.loginpost),

   path('admin_addcategory/',views.admin_addcategory),
   path('admin_addcategorypost/',views.admin_addcategorypost),


   path('admin_add_company_details/',views.admin_add_company_details),
   path('admin_add_company_detailspost/',views.admin_add_company_detailspost),

   path('admin_add_deliveryboy/',views.admin_add_deliveryboy),
   path('search_deliveryboy/',views.search_deliveryboy),
   path('admin_add_deliveryboypost/',views.admin_add_deliveryboypost),

   path('admin_add_cabnet/',views.admin_add_cabnet),
   path('admin_add_cabnetpost/',views.admin_add_cabnetpost),

   path('admin_add_cooler/',views.admin_add_cooler),
   path('admin_add_cooler_post/',views.admin_add_cooler_post),

   path('admin_add_graphcis/',views.admin_add_graphcis),
   path('admin_add_graphcispost/',views.admin_add_graphcispost),

   path('admin_add_keyboard/',views.admin_add_keyboard),
    path('admin_add_keyboardpost/',views.admin_add_keyboardpost),

    path('admin_add_monitor/',views.admin_add_monitor),
   path('admin_add_monitorpost/',views.admin_add_monitorpost),

   path('admin_add_motherboard/',views.admin_add_motherboard),
   path('admin_add_motherboardpost/',views.admin_add_motherboardpost),

   path('admin_add_processor/',views.admin_add_processor),
   path('admin_add_processorpost/',views.admin_add_processorpost),

   path('admin_add_ram/',views.admin_add_ram),
   path('admin_add_rampost/',views.admin_add_rampost),

   path('admin_add_smps/',views.admin_add_smps),
   path('admin_add_smpspost/',views.admin_add_smpspost),

   path('admin_add_storage/',views.admin_add_storage),
   path('admin_add_storagepost/',views.admin_add_storagepost),

   path('admin_add_subcategory/',views.admin_add_subcategory),
   path('admin_add_subcategorypost/',views.admin_add_subcategorypost),

   path('admin_home/',views.admin_home),
   path('assigned_order_delevery_ststus/<id>',views.assigned_order_delevery_ststus),
   path('assigned_order_delevery_ststus_post/',views.assigned_order_delevery_ststus_post),



   path('assign_delivery_boy/<id>',views.assign_delivery_boy),
   path('assign_delivery_boypost/',views.assign_delivery_boypost),

   path('assign_delivery_boypost/',views.assign_delivery_boypost),
   path('view_assigned_delivery_boys/',views.view_assigned_delivery_boys),
   path('assigned_delivery_boys_search/',views.assigned_delivery_boys_search),



   path('edit_cabnet/<id>',views.edit_cabnet),
   path('edit_cabnetpost/',views.edit_cabnetpost),
   path('delete_cabnet/<id>',views.delete_cabnet),
   path('search_cabnet/',views.search_cabnet),

   path('edit_category/<id>',views.edit_category),
   path('edit_categorypost/',views.edit_categorypost),

   path('edit_company_deatil/<id>',views.edit_company_deatil),
   path('edit_company_deatilpost/',views.edit_company_deatilpost),

   path('edit_cooler/<id>',views.edit_cooler),
   path('edit_coolerpost/',views.edit_coolerpost),

   path('edit_deliveryboy/',views.edit_deliveryboy),
   path('edit_deliveryboypost/',views.edit_deliveryboypost),

   path('edit_graphics/<id>',views.edit_graphics),
   path('edit_graphicspost/',views.edit_graphicspost),
   path('delete_graphics/<id>',views.delete_graphics),
   path('search_graphics/',views.search_graphics),

   path('edit_keyboard/<id>',views.edit_keyboard),
   path('edit_keyboardpost/',views.edit_keyboardpost),
   path('delete_keyboard/<id>',views.delete_keyboard),
   path('search_keyboard/',views.search_keyboard),

   path('edit_monitor/<id>',views.edit_monitor),
   path('edit_monitorpost/',views.edit_monitorpost),
   path('delete_monitor/<id>',views.delete_monitor),
   path('search_monitor/',views.search_monitor),

   path('edit_motherboard/<id>',views.edit_motherboard),
   path('edit_motherboardpost/',views.edit_motherboardpost),
   path('delete_motherboard/<id>', views.delete_motherboard),
   path('search_motherboard/', views.search_motherboard),

   path('edit_processor/<id>',views.edit_processor),
   path('edit_processorpost/',views.edit_processorpost),
   path('delete_processor/<id>',views.delete_processor),
   path('search_processor/',views.search_processor),

   path('edit_ram/<id>',views.edit_ram),
   path('edit_rampost/',views.edit_rampost),
   path('delete_ram/<id>',views.delete_ram),
   path('search_ram/',views.search_ram),

   path('edit_smps/<id>',views.edit_smps),
   path('edit_smpspost/',views.edit_smpspost),
   path('delete_smps/<id>',views.delete_smps),
   path('search_smps/',views.search_smps),



   path('edit_storage/<id>',views.edit_storage),
   path('edit_storagepost/',views.edit_storagepost),
   path('delete_storage/<id>',views.delete_storage),
   path('search_storage/',views.search_storage),

   path('edit_subcategory/',views.edit_subcategory),
   path('edit_subcategorypost/',views.edit_subcategorypost),

   path('view_assigened_order_and_status/',views.view_assigened_order_and_status),
   path('view_cabnet/',views.view_cabnet),

   path('view_category/',views.view_category),
   path('delete_category/<id>',views.delete_category),

   path('view_company_detail/',views.view_company_detail),

   path('view_cooler/',views.view_cooler),
   path('delete_cooler/<id>', views.delete_cooler),
   path('search_cooler/', views.search_cooler),

   path('view_deliveryboy/',views.view_deliveryboy),
   path('view_graphics/',views.view_graphics),
   path('view_keyboard/',views.view_keyboard),
   path('view_monitor/',views.view_monitor),
   path('view_motherboard/',views.view_motherboard),
   path('view_orders_reject_reason/',views.view_orders_reject_reason),

    path('view_orders_and_assign/<id>',views.view_orders_and_assign),
    path('admin_view_orders/',views.admin_view_orders),
    path('acceptuserorder/<id>',views.acceptuserorder),
    path('rejectuserorder/<id>',views.rejectuserorder),

   path('view_processor/',views.view_processor),
   path('view_ram/',views.view_ram),
   path('view_smps/',views.view_smps),
   path('view_storage/',views.view_storage),
   path('view_subcategory/',views.view_subcategory),
   path('assigned_order_delivery_reject_status/',views.assigned_order_delivery_reject_status),
   #path('assigned_order_delivery_delivery_status/',views.assigned_order_delivery_delivery_status),
   path('assigned_order_delivery_delivery_statuspost/',views.assigned_order_delivery_delivery_statuspost),

   path('edit_deliveryboy_profile/',views.edit_deliveryboy_profile),
   path('edit_deliveryboy_profilepost/',views.edit_deliveryboy_profilepost),

   path('view_assigned_order_and_take_order/',views.view_assigned_order_and_take_order),
   path('view_deliveryboy_profile/',views.view_deliveryboy_profile),

   path('deliveryboy_changepassword/',views.deliveryboy_changepassword),
   path('deliveryboy_changepasswordpost/',views.deliveryboy_changepasswordpost),

   path('edit_user_profile/',views.edit_user_profile),
   path('edit_user_profilepost/',views.edit_user_profilepost),

   path('order_product_cart/',views.order_product_cart),
   path('order_product_cartpost',views.order_product_cartpost),

   path('select_assemble_or_orderproduct/',views.select_assemble_or_orderproduct),
   path('select_any_product/',views.select_any_product),

   path('select_cabnet/',views.select_cabnet),
   path('search_select_cabnet/',views.search_select_cabnet),
   path('addtocart_cabnet/',views.addtocart_cabnet),

   path('select_category/',views.select_category),

   path('select_cooler/',views.select_cooler),
   path('search_select_cooler/',views.search_select_cooler),
   path('addtocart_cooler/',views.addtocart_cooler),

   path('select_fan/',views.select_fan),
   path('select_graphicscard/',views.select_graphicscard),
   path('search_select_graphicscard/',views.search_select_graphicscard),
   path('addtocart_graphicscard/',views.addtocart_graphicscard),
   path('select_keyboard/',views.select_keyboard),
   path('search_select_keyboard/',views.search_select_keyboard),
   path('addtocart_keyboard/',views.addtocart_keyboard),
   path('select_monitor/',views.select_monitor),
   path('search_select_monitor/',views.search_select_monitor),
   path('addtocart_selectmonitor/',views.addtocart_selectmonitor),
   path('select_motherboard/',views.select_motherboard),
   path('search_select_motherboard/',views.search_select_motherboard),
   path('addtocart_selectmotherboard/',views.addtocart_selectmotherboard),
   path('select_mouse/',views.select_mouse),
   path('select_processor/',views.select_processor),
   path('search_select_procssor/',views.search_select_procssor),
   path('addtocart_procesor/',views.addtocart_procesor),
   path('select_ram/',views.select_ram),
   path('search_select_ram/',views.search_select_ram),
   path('addtocart_ram/',views.addtocart_ram),
   path('select_smps/',views.select_smps),
   path('search_select_smps/',views.search_select_smps),
   path('addtocart_smps/',views.addtocart_smps),
   path('select_storage/',views.select_storage),
   path('search_select_storage/',views.search_select_storage),
   path('addtocart_storage/',views.addtocart_storage),
   path('user_buy_assembleproduct/',views.user_buy_assembleproduct),
   path('user_assemble_ram/',views.user_assemble_ram),
   path('user_assemble_processor/',views.user_assemble_processor),
   path('user_assemble_storage/',views.user_assemble_storage),
   path('user_assemble_graphics/',views.user_assemble_graphics),
   path('addtocart_assemblegraphics/',views.addtocart_assemblegraphics),

   path('user_assemble_processor_inter/',views.user_assemble_processor_inter),
   path('addtocart_assembleprocessor_inter/',views.addtocart_assembleprocessor_inter),
   path('user_assemble_ram_inter/',views.user_assemble_ram_inter),
   path('addtocart_assembleram_inter/',views.addtocart_assembleram_inter),
   path('user_assemble_storage_inter/',views.user_assemble_storage_inter),
   path('addtocart_assemblestorage_inter/',views.addtocart_assemblestorage_inter),
   path('user_assemble_graphics_inter/',views.user_assemble_graphics_inter),
   path('addtocart_assemblegraphics_inter/',views.addtocart_assemblegraphics_inter),
   path('user_buy_assembleproduct_inter/', views.user_buy_assembleproduct_inter),
   path('addtocart_assemblemotherboard_inter/', views.addtocart_assemblemotherboard_inter),
   path('user_assemble_smps_inter/',views.user_assemble_smps_inter),
   path('aaddtocart_assemblesmps_inter/',views.aaddtocart_assemblesmps_inter),
   path('user_assemble_cabinet_inter/',views.user_assemble_cabinet_inter),
   path('addtocart_assemble_cabinet_inter/',views.addtocart_assemble_cabinet_inter),
   path('user_assemble_monitor_inter/',views.user_assemble_monitor_inter),
   path('addtocart_assemble_monitor_inter/',views.addtocart_assemble_monitor_inter),
   path('user_assemble_cooler_inter/',views.user_assemble_cooler_inter),
   path('addtocart_assemble_cooler_inter/',views.addtocart_assemble_cooler_inter),

   path('user_assemble_processor_adv/',views.user_assemble_processor_adv),
   path('addtocart_assembleprocessor_adv/',views.addtocart_assembleprocessor_adv),

   path('user_assemble_ram_adv/',views.user_assemble_ram_adv),
   path('addtocart_assembleram_adv/',views.addtocart_assembleram_adv),

   path('user_assemble_storage_adv/',views.user_assemble_storage_adv),
   path('addtocart_assemblestorage_adv/',views.addtocart_assemblestorage_adv),

   path('user_assemble_graphics_adv/',views.user_assemble_graphics_adv),
   path('addtocart_assemblegraphics_adv/',views.addtocart_assemblegraphics_adv),

   path('user_buy_assembleproduct_adv/', views.user_buy_assembleproduct_adv),
   path('addtocart_assemblemotherboard_adv/', views.addtocart_assemblemotherboard_adv),

   path('user_assemble_smps_adv/',views.user_assemble_smps_adv),
   path('aaddtocart_assemblesmps_adv/',views.aaddtocart_assemblesmps_adv),

   path('user_assemble_cabinet_adv/',views.user_assemble_cabinet_adv),
   path('addtocart_assemble_cabinet_adv/',views.addtocart_assemble_cabinet_adv),

   path('user_assemble_monitor_adv/',views.user_assemble_monitor_adv),
   path('addtocart_assemble_monitor_adv/',views.addtocart_assemble_monitor_adv),

   path('user_assemble_cooler_adv/',views.user_assemble_cooler_adv),
   path('addtocart_assemble_cooler_adv/',views.addtocart_assemble_cooler_adv),
   #path('user_order/<id>',views.user_order),















   path('user_assemble_cabinet/',views.user_assemble_cabinet),
   path('user_assemble_monitor/',views.user_assemble_monitor),
   path('user_assemble_cooler/',views.user_assemble_cooler),
   path('addtocart_assemble_cooler/',views.addtocart_assemble_cooler),
   path('addtocart_assemble_monitor/',views.addtocart_assemble_monitor),



   path('addtocart_assemble_cabinet/',views.addtocart_assemble_cabinet),

   path('user_assemble_smps/',views.user_assemble_smps),
   path('addtocart_assemblesmps/',views.addtocart_assemblesmps),





   path('addtocart_smps/',views.addtocart_smps),
   path('addtocart_graphicscard/',views.addtocart_graphicscard),

   path('addtocart_assemblestorage/',views.addtocart_assemblestorage),

   path('addtocart_assembleprocessor/',views.addtocart_assembleprocessor),

   path('addtocart_assembleram/',views.addtocart_assembleram),


   path('addtocart_assemblemotherboard/',views.addtocart_assemblemotherboard),

   path('cahange_password/',views.cahange_password),
   path('cahange_passwordpost/',views.cahange_passwordpost),

   path('user_home/',views.user_home),

   path('user_register/',views.user_register),
   path('user_registerpost/',views.user_registerpost),

   path('view_cart/',views.view_cart),
   path('view_order_status/',views.view_order_status),
   path('view_user_profile/',views.view_user_profile),

   path('deliveryboy_home/',views.deliveryboy_home),
   path('user_bill/',views.user_bill),
   path('placeorder/',views.placeorder),
]
