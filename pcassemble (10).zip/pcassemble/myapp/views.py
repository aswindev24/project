from datetime import datetime

from django.core.files.storage import FileSystemStorage
from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import *
# Create your views here.
def login(request):
    return render(request,'login.html')
def loginpost(request):
    name=request.POST['textfield']
    password=request.POST['textfield2']

    lobj=Login.objects.filter(username=name,password=password)
    if lobj.exists():
        lobj2=Login.objects.get(username=name,password=password)
        request.session['lid']=lobj2.id
        if lobj2.type=='admin':
            return HttpResponse("<script>alert('login ok');window.location='/myapp/admin_home/'</script>")
        elif lobj2.type=='user':
            return HttpResponse("<script>alert('login ok'); window.location='/myapp/user_home/'</script>")
        elif lobj2.type=="deliveryboy":
            return HttpResponse("<script>alert('login ok'); window.location='/myapp/deliveryboy_home/'</script>")
    else:
        return  HttpResponse("<script>alert('user not found ok'); window.location='/myapp/login.html'</script>")



def admin_addcategory(request):
    return render(request,'admin/add_category.html')
def admin_addcategorypost(request):
    categoryname=request.POST['textfield']

    cobj=Category()
    cobj.categoryname=categoryname
    cobj.save()
    return HttpResponse("ok")



def admin_add_company_details(request):
    return render(request,'admin/add_company_detail.html')
def admin_add_company_detailspost(request):
    name=request.POST['textfield']
    email=request.POST['textfield2']
    number=request.POST['textfield3']
    street=request.POST['textfield4']
    place=request.POST['textfield5']
    post=request.POST['textfield6']
    district=request.POST['textfield7']
    state=request.POST['textfield8']
    pin=request.POST['textfield9']
    opentime=request.POST['textfield10']
    closetime=request.POST['textfield11']

    cobj=Shop()
    cobj.name=name
    cobj.email=email
    cobj.number=number
    cobj.street=street
    cobj.place=place
    cobj.post=post
    cobj.district=district
    cobj.state=state
    cobj.pin=pin
    cobj.opentime=opentime
    cobj.closetime=closetime
    cobj.save()

    return HttpResponse("ok")

def admin_add_deliveryboy(request):
    return render(request,'admin/add_deliveryboy.html')
def search_deliveryboy(request):
    s=request.POST['textfield']
    obj = Deliveryboy.objects.filter(name__icontains=s)
    return render(request, 'admin/view_deliveryboy.html', {'data': obj})
def admin_add_deliveryboypost(request):
    name=request.POST['textfield']
    email=request.POST['textfield2']
    dob=request.POST['textfield3']
    street=request.POST['textfield4']
    place=request.POST['textfield5']
    post=request.POST['textfield6']
    district=request.POST['textfield7']
    pincode=request.POST['textfield8']
    password=request.POST['textfield9']

    loobj2=Login()
    loobj2.username=email
    loobj2.password=password
    loobj2.type="deliveryboy"
    loobj2.save()

    ob2=Deliveryboy()
    ob2.name=name
    ob2.email=email
    ob2.dob=dob
    ob2.street=street
    ob2.place=place
    ob2.post=post
    ob2.district=district
    ob2.pincode=pincode
    ob2.LOGIN=loobj2
    ob2.save()

    return  HttpResponse("<script>alert('registered'); </script>")

def admin_add_cabnet(request):
    data = Category.objects.all()
    motherboard = Motherboard.objects.all()
    return render(request,'admin/add_cabinet.html',{'data':data,'motherboard':motherboard})
def admin_add_cabnetpost(request):
    category=request.POST['select']
    select = request.POST['select2']
    name=request.POST['textfield']
    photo=request.FILES['fileField']
    details=request.POST['textarea']
    price=request.POST['textfield2']

    fs = FileSystemStorage()
    date = datetime.now().strftime("%Y%m%d-%H%M%S") + '.jpg'
    fs.save(date, photo)
    path = fs.url(date)

    obj = Cabinet()
    obj.photo = path
    obj.details = details
    obj.price = price
    obj.name = name
    obj.CATEGORY_id = category
    obj.Motherboard_id = select
    obj.save()

    return HttpResponse("ok")



def admin_add_cooler(request):
    data = Category.objects.all()
    motherboard=Motherboard.objects.all()
    return render(request,'admin/add_cooler.html',{'data':data,'motherboard':motherboard})

def admin_add_cooler_post(request):
    category = request.POST['select']
    select=request.POST['select2']
    name = request.POST['textfield']
    photo = request.FILES['fileField']
    details = request.POST['textarea']
    price = request.POST['textfield2']

    fs = FileSystemStorage()
    date = datetime.now().strftime("%Y-%m-%d-%H-%M-%S") + '.jpg'
    fs.save(date, photo)
    path = fs.url(date)



    obj = Cooler()
    obj.photo = path
    obj.details = details
    obj.price = price
    obj.name = name

    obj.CATEGORY_id= category
    obj.Motherboard_id=select
    obj.save()

    return HttpResponse('SUCCESS')


def admin_add_graphcis(request):
    data = Category.objects.all()
    motherboard = Motherboard.objects.all()
    return render(request,'admin/add_graphcis.html',{'data':data,'motherboard':motherboard})
def admin_add_graphcispost(request):
    category = request.POST['select']
    select = request.POST['select2']
    name=request.POST['textfield']
    photo=request.FILES['fileField']
    details=request.POST['textarea']
    price=request.POST['textfield2']

    fs = FileSystemStorage()
    date = datetime.now().strftime("%Y-%m-%d-%H-%M-%S") + '.jpg'
    fs.save(date, photo)
    path = fs.url(date)

    obj = Graphicscard()
    obj.photo = path
    obj.details = details
    obj.price = price
    obj.name = name
    obj.CATEGORY_id = category
    obj.Motherboard_id = select
    obj.save()

    return HttpResponse("ok")

def admin_add_keyboard(request):
    data = Category.objects.all()
    motherboard = Motherboard.objects.all()
    return render(request,'admin/add_keyboard.html',{'data':data,'motherboard':motherboard})
def admin_add_keyboardpost(request):
    category=request.POST['select']
    select=request.POST['select2']
    name=request.POST['textfield']
    photo=request.FILES['fileField']
    details=request.POST['textarea']
    price=request.POST["textfield2"]

    fs = FileSystemStorage()
    date = datetime.now().strftime("%Y-%m-%d-%H-%M-%S") + '.jpg'
    fs.save(date, photo)
    path = fs.url(date)

    obj = Keyboard()
    obj.photo = path
    obj.details = details
    obj.price = price
    obj.name = name
    obj.CATEGORY_id = category
    obj.Motherboard_id = select
    obj.save()

    return HttpResponse("OK")

def admin_add_monitor(request):
    data = Category.objects.all()
    motherboard = Motherboard.objects.all()
    return render(request,'admin/add_monitor.html',{'data':data,'motherboard':motherboard})
def admin_add_monitorpost(request):
    category=request.POST['select']
    select=request.POST['select2']
    name=request.POST['textfield']
    photo=request.FILES['fileField']
    details=request.POST['textarea']
    price=request.POST['textfield2']

    fs = FileSystemStorage()
    date = datetime.now().strftime("%Y-%m-%d-%H-%M-%S") + '.jpg'
    fs.save(date, photo)
    path = fs.url(date)

    obj = Monitor()
    obj.photo = path
    obj.details = details
    obj.price = price
    obj.name = name
    obj.CATEGORY_id = category
    obj.Motherboard_id = select
    obj.save()

    return HttpResponse("ok")

def admin_add_motherboard(request):
    data=Category.objects.all()
    return render(request,'admin/add_motherboard.html',{'data':data})
def admin_add_motherboardpost(request):
    category = request.POST['select']
    motherboardname = request.POST['textfield']
    photo = request.FILES['fileField']
    details = request.POST['textarea']
    price = request.POST['textfield2']



    fs=FileSystemStorage()
    date=datetime.now().strftime("%Y-%m-%d-%H-%M-%S")+'.jpg'
    fs.save(date,photo)
    path=fs.url(date)

    obj=Motherboard()
    obj.photo=path
    obj.details=details
    obj.price=price
    obj.motherboardname=motherboardname
    obj.CATEGORY_id = category

    obj.save()

    return  HttpResponse("ok")

def admin_add_processor(request):
    data = Category.objects.all()
    motherboard = Motherboard.objects.all()
    return render(request,'admin/add_processor.html',{'data':data,'motherboard':motherboard})
def admin_add_processorpost(request):
    category = request.POST['select']
    select=request.POST['select2']
    name = request.POST['textfield']
    photo = request.FILES['fileField']
    details = request.POST['textarea']
    price = request.POST['textfield2']

    fs = FileSystemStorage()
    date = datetime.now().strftime("%Y-%m-%d-%H-%M-%S") + '.jpg'
    fs.save(date, photo)
    path = fs.url(date)

    obj = Processor()
    obj.photo = path
    obj.details = details
    obj.price = price
    obj.NAME = name
    obj.CATEGORY_id = category
    obj.Motherboard_id = select
    obj.save()

    return HttpResponse("ok")

def admin_add_ram(request):
    data = Category.objects.all()
    motherboard = Motherboard.objects.all()
    return render(request,'admin/add_ram.html',{'data':data,'motherboard':motherboard})
def admin_add_rampost(request):
    category = request.POST['select']
    select = request.POST['select2']
    name = request.POST['textfield']
    photo = request.FILES['fileField']
    details = request.POST['textarea']
    price = request.POST['textfield2']

    fs = FileSystemStorage()
    date = datetime.now().strftime("%Y-%m-%d-%H-%M-%S") + '.jpg'
    fs.save(date, photo)
    path = fs.url(date)

    obj = Ram()
    obj.photo = path
    obj.details = details
    obj.price = price
    obj.name = name
    obj.CATEGORY_id = category
    obj.Motherboard_id = select
    obj.save()

    return HttpResponse("ok")

def admin_add_smps(request):
    data = Category.objects.all()
    motherboard = Motherboard.objects.all()
    return render(request,'admin/add_smps.html',{'data':data,'motherboard':motherboard})
def admin_add_smpspost(request):
    category = request.POST['select']
    select=request.POST['select2']
    name = request.POST['textfield']
    photo = request.FILES['fileField']
    details = request.POST['textarea']
    price = request.POST['textfield2']

    fs = FileSystemStorage()
    date = datetime.now().strftime("%Y-%m-%d-%H-%M-%S") + '.jpg'
    fs.save(date, photo)
    path = fs.url(date)

    obj = Smps()
    obj.photo = path
    obj.details = details
    obj.price = price
    obj.name = name
    obj.CATEGORY_id = category
    obj.Motherboard_id = select
    obj.save()


    return HttpResponse("ok")

def admin_add_storage(request):
    data = Category.objects.all()
    motherboard = Motherboard.objects.all()
    return render(request,'admin/add_storage.html',{'data':data,'motherboard':motherboard})
def admin_add_storagepost(request):
    category = request.POST['select']
    select=request.POST['select2']
    name = request.POST['textfield']
    photo = request.FILES['fileField']
    details = request.POST['textarea']
    price = request.POST['textfield2']

    fs = FileSystemStorage()
    date = datetime.now().strftime("%Y-%m-%d-%H-%M-%S") + '.jpg'
    fs.save(date, photo)
    path = fs.url(date)

    obj = Storage()
    obj.photo = path
    obj.details = details
    obj.price = price
    obj.name = name
    obj.CATEGORY_id = category
    obj.Motherboard_id = select
    obj.save()

    return HttpResponse("ok")

def admin_add_subcategory(request):
    return render(request,'admin/add_subcategory.html')
def admin_add_subcategorypost(request):
    add_sub_name=request.POST['textfield']
    return HttpResponse("OK")

def admin_home(request):
    return render(request,'admin/admin_home.html')

def assign_delivery_boy(request,id):
    a=Deliveryboy.objects.filter(status=True)
    return render(request,'admin/assign_delivery_boy.html',{'data':a,'data1':id})


def assign_delivery_boypost(request):
    id=request.POST['id']
    deliveryboynamelist=request.POST['select']
    a=Assign()
    a.ORDERMAIN_ID=Order_main.objects.get(id=id)
    delivery_boy_instance = Deliveryboy.objects.get(id=deliveryboynamelist)
    a.DELIVERYBOY_ID=Deliveryboy.objects.get(id=deliveryboynamelist)
    a.aasigndate=datetime.now().today().date()
    a.status='assigned'

    delivery_boy_instance.status = False
    delivery_boy_instance.save()

    a.save()
    return HttpResponse('''<script>alert('assigned');window.location='/myapp/admin_home/'</script>''')

def edit_cabnet(request,id):
    ed=Cabinet.objects.get(id=id)
    ca=Category.objects.all()
    mo=Motherboard.objects.all()
    return render(request,'admin/edit_cabnet.html',{'data':ed,'data1':ca,'data2':mo})
def edit_cabnetpost(request):
    category = request.POST['select']
    name = request.POST['textfield']

    details = request.POST['textarea']
    select = request.POST['select2']
    id=request.POST['id']
    price = request.POST['textfield2']
    obj = Cabinet.objects.get(id=id)

    if 'fileField' in request.FILES:
        photo = request.FILES['fileField']

        fs = FileSystemStorage()
        date = datetime.now().strftime("%Y%m%d-%H%M%S") + '.jpg'
        fs.save(date, photo)
        path = fs.url(date)
        obj.photo = path
        obj.details = details
        obj.price = price
        obj.name = name
        obj.CATEGORY_id = category
        obj.Motherboard_id = select
        obj.save()

    obj.details = details
    obj.price = price
    obj.name = name
    obj.CATEGORY_id = category
    obj.Motherboard_id = select
    obj.save()

    return HttpResponse("<script>alert('UPDATED'); window.location='/myapp/view_cabnet/'</script>")

def delete_cabnet(request,id):
    d=Cabinet.objects.filter(id=id).delete()
    return redirect('/myapp/view_cabnet/')

def view_assigned_delivery_boys(request):
    ob=Assign.objects.all()
    return  render(request,'admin/view_assigned_delivery_boys.html',{'data':ob})

def assigned_delivery_boys_search(request):
    fromdate=request.POST['textfield']
    todate=request.POST['textfield1']
    ob=Assign.objects.filter(aasigndate__range=[fromdate,todate])
    return render(request,'admin/view_assigned_delivery_boys.html',{'data':ob})



def search_cabnet(request):
    s=request.POST['textfield']
    obj = Cabinet.objects.filter(name__icontains=s)
    return render(request, 'admin/view_cabnet.html', {'data': obj})

def edit_category(request,id):
    d=Category.objects.get(id=id)
    return render(request,'admin/edit_category.html',{'data':d})
def edit_categorypost(request):
    categoryname = request.POST['textfield']
    id=request.POST['id']
    obj = Category.objects.get(id=id)
    obj.categoryname=categoryname
    obj.save()
    return HttpResponse("ok")

def edit_company_deatil(request,id):
    ec = Shop.objects.get(id=id)
    return render(request,'admin/edit_company_deatil.html',{'data':ec})

def edit_company_deatilpost(request):
    name = request.POST['textfield']
    email = request.POST['textfield2']
    number = request.POST['textfield3']
    street = request.POST['textfield4']
    place = request.POST['textfield5']
    post = request.POST['textfield6']
    district = request.POST['textfield7']
    state = request.POST['textfield8']
    pin = request.POST['textfield9']
    opentime = request.POST['textfield10']
    closetime = request.POST['textfield11']
    id = request.POST['id']

    ec = Shop.objects.get(id=id)

    ec.name=name
    ec.email=email
    ec.number=number
    ec.street=street
    ec.place=place
    ec.post=post
    ec.district=district
    ec.state=state
    ec.pin=pin
    ec.opentime=opentime
    ec.closetime=closetime
    ec.save()
    return HttpResponse("ok")

def edit_cooler(request,id):
    coo = Cooler.objects.get(id=id)
    ca = Category.objects.all()
    mo = Motherboard.objects.all()
    return render(request,'admin/edit_cooler.html',{'data':coo,'data1':ca,'data2':mo})

def edit_coolerpost(request):
    id = request.POST['id']
    category = request.POST['select']
    name = request.POST['textfield']
    select = request.POST['select2']

    details = request.POST['textarea']
    price = request.POST['textfield2']

    obj = Cooler.objects.get(id=id)
    if 'fileField' in request.FILES:
        photo = request.FILES['fileField']

        fs = FileSystemStorage()
        date = datetime.now().strftime("%Y%m%d-%H%M%S") + '.jpg'
        fs.save(date,photo)
        path = fs.url(date)

        obj.photo = path
        obj.details = details
        obj.price = price
        obj.name = name
        obj.CATEGORY_id = category
        obj.Motherboard_id = select
        obj.save()

    obj.details = details
    obj.price = price
    obj.name = name
    obj.CATEGORY_id = category
    obj.Motherboard_id = select
    obj.save()

    return HttpResponse("<script>alert('UPDATED'); window.location='/myapp/view_cooler/'</script>")

def delete_cooler(request,id):
    d=Cooler.objects.filter(id=id).delete()
    return redirect('/myapp/view_cooler/')

def search_cooler(request):
    c=request.POST['textfield']
    obj = Cooler.objects.filter(name__icontains=c)
    return render(request, 'admin/view_cooler.html', {'data': obj})

def edit_deliveryboy(request):
    return render(request,'admin/edit_deliveryboy.html')
def edit_deliveryboypost(request):
    name = request.POST['textfield']
    email = request.POST['textfield2']
    dob = request.POST['textfield3']
    street = request.POST['textfield4']
    place = request.POST['textfield5']
    post = request.POST['textfield6']
    district = request.POST['textfield7']
    pincode = request.POST['textfield8']
    password = request.POST['textfield9']

    ob=Deliveryboy.objects.get(LOGIN=request.session["lid"])
    ob.name=name
    ob.street=street
    ob.dob=dob
    ob.place=place
    ob.pincode=pincode
    ob.post=post
    ob.email=email

    ob.save()

    return HttpResponse("OK")
def delete_keyboard(request,id):
    d=Keyboard.objects.filter(id=id).delete()
    return redirect('/myapp/view_keyboard/')

def search_keyboard(request):
    c=request.POST['textfield']
    obj = Keyboard.objects.filter(name__icontains=c)
    return render(request, 'admin/view_keyboard.html', {'data': obj})

def edit_graphics(request,id):
    ed = Graphicscard.objects.get(id=id)
    ca = Category.objects.all()
    mo = Motherboard.objects.all()
    return render(request,'admin/edit_graphics.html',{'data':ed,'data1':ca,'data2':mo})
def edit_graphicspost(request):
    category = request.POST['select']
    name = request.POST['textfield']

    details = request.POST['textarea']
    select = request.POST['select2']
    id = request.POST['id']
    price = request.POST['textfield2']
    obj = Graphicscard.objects.get(id=id)

    if 'fileField' in request.FILES:
        photo = request.FILES['fileField']

        fs = FileSystemStorage()
        date = datetime.now().strftime("%Y%m%d-%H%M%S") + '.jpg'
        fs.save(date, photo)
        path = fs.url(date)
        obj.photo = path
        obj.details = details
        obj.price = price
        obj.name = name
        obj.CATEGORY_id = category
        obj.Motherboard_id = select
        obj.save()

    obj.details = details
    obj.price = price
    obj.name = name
    obj.CATEGORY_id = category
    obj.Motherboard_id = select
    obj.save()

    return HttpResponse("<script>alert('UPDATED'); window.location='/myapp/view_graphics/'</script>")

def delete_graphics(request,id):
    d=Graphicscard.objects.filter(id=id).delete()
    return redirect('/myapp/view_graphics/')
def search_graphics(request):
    c=request.POST['textfield']
    obj = Graphicscard.objects.filter(name__icontains=c)
    return render(request, 'admin/view_graphics.html', {'data': obj})

def edit_keyboard(request,id):
    ed = Keyboard.objects.get(id=id)
    ca = Category.objects.all()
    mo = Motherboard.objects.all()
    return render(request,'admin/edit_keyboard.html',{'data':ed,'data1':ca,'data2':mo})
def edit_keyboardpost(request):
    category = request.POST['select']
    name = request.POST['textfield']

    details = request.POST['textarea']
    select = request.POST['select2']
    id = request.POST['id']
    price = request.POST['textfield2']
    obj = Keyboard.objects.get(id=id)

    if 'fileField' in request.FILES:
        photo = request.FILES['fileField']

        fs = FileSystemStorage()
        date = datetime.now().strftime("%Y%m%d-%H%M%S") + '.jpg'
        fs.save(date, photo)
        path = fs.url(date)
        obj.photo = path
        obj.details = details
        obj.price = price
        obj.name = name
        obj.CATEGORY_id = category
        obj.Motherboard_id = select
        obj.save()

    obj.details = details
    obj.price = price
    obj.name = name
    obj.CATEGORY_id = category
    obj.Motherboard_id = select
    obj.save()

    return HttpResponse("<script>alert('UPDATED'); window.location='/myapp/view_keyboard/'</script>")

def edit_monitor(request,id):
    ed = Monitor.objects.get(id=id)
    ca = Category.objects.all()
    mo = Motherboard.objects.all()
    return render(request,'admin/edit_monitor.html',{'data':ed,'data1':ca,'data2':mo})
def edit_monitorpost(request):
    category = request.POST['select']
    name = request.POST['textfield']

    details = request.POST['textarea']
    select = request.POST['select2']
    id = request.POST['id']
    price = request.POST['textfield2']
    obj = Monitor.objects.get(id=id)

    if 'fileField' in request.FILES:
        photo = request.FILES['fileField']

        fs = FileSystemStorage()
        date = datetime.now().strftime("%Y%m%d-%H%M%S") + '.jpg'
        fs.save(date, photo)
        path = fs.url(date)
        obj.photo = path
        obj.details = details
        obj.price = price
        obj.name = name
        obj.CATEGORY_id = category
        obj.Motherboard_id = select
        obj.save()

    obj.details = details
    obj.price = price
    obj.name = name
    obj.CATEGORY_id = category
    obj.Motherboard_id = select
    obj.save()

    return HttpResponse("<script>alert('UPDATED'); window.location='/myapp/view_monitor/'</script>")

def edit_motherboard(request,id):
    ed = Motherboard.objects.get(id=id)
    ca = Category.objects.all()

    return render(request,'admin/edit_motherboard.html',{'data':ed,'data1':ca})
def edit_motherboardpost(request):
    category = request.POST['select']
    name = request.POST['textfield']

    details = request.POST['textarea']

    id = request.POST['id']
    price = request.POST['textfield2']
    obj = Motherboard.objects.get(id=id)

    if 'fileField' in request.FILES:
        photo = request.FILES['fileField']

        fs = FileSystemStorage()
        date = datetime.now().strftime("%Y%m%d-%H%M%S") + '.jpg'
        fs.save(date, photo)
        path = fs.url(date)
        obj.photo = path
        obj.details = details
        obj.price = price
        obj.motherboardname = name
        obj.CATEGORY_id = category

        obj.save()

    obj.details = details
    obj.price = price
    obj.motherboardname = name
    obj.CATEGORY_id = category

    obj.save()

    return HttpResponse("<script>alert('UPDATED'); window.location='/myapp/view_motherboard/'</script>")

def delete_motherboard(request,id):
    d=Motherboard.objects.filter(id=id).delete()
    return redirect('/myapp/view_motherboard/')

def search_motherboard(request):
    c=request.POST['textfield']
    obj = Motherboard.objects.filter(motherboardname__icontains=c)
    return render(request, 'admin/view_motherboard.html', {'data': obj})


def delete_monitor(request,id):
    d=Monitor.objects.filter(id=id).delete()
    return redirect('/myapp/view_monitor/')

def search_monitor(request):
    c=request.POST['textfield']
    obj = Monitor.objects.filter(name__icontains=c)
    return render(request, 'admin/view_monitor.html', {'data': obj})

def edit_processor(request,id):
    ed = Processor.objects.get(id=id)
    ca = Category.objects.all()
    mo = Motherboard.objects.all()
    return render(request,'admin/edit_processor.html',{'data':ed,'data1':ca,'data2':mo})
def edit_processorpost(request):
    category = request.POST['select']
    name = request.POST['textfield']

    details = request.POST['textarea']
    select = request.POST['select2']
    id = request.POST['id']
    price = request.POST['textfield2']
    obj = Processor.objects.get(id=id)

    if 'fileField' in request.FILES:
        photo = request.FILES['fileField']

        fs = FileSystemStorage()
        date = datetime.now().strftime("%Y%m%d-%H%M%S") + '.jpg'
        fs.save(date, photo)
        path = fs.url(date)
        obj.photo = path
        obj.details = details
        obj.price = price
        obj.NAME= name
        obj.CATEGORY_id = category
        obj.Motherboard_id = select
        obj.save()

    obj.details = details
    obj.price = price
    obj.NAME = name
    obj.CATEGORY_id = category
    obj.Motherboard_id = select
    obj.save()

    return HttpResponse("<script>alert('UPDATED'); window.location='/myapp/view_processor/'</script>")

def delete_processor(request,id):
    d=Processor.objects.filter(id=id).delete()
    return redirect('/myapp/view_processor/')
def search_processor(request):
    p=request.POST['textfield']
    obj = Processor.objects.filter(NAME__icontains=p)
    return render(request, 'admin/view_processor.html', {'data': obj})

def edit_ram(request,id):
    r = Ram.objects.get(id=id)
    ca = Category.objects.all()
    mo = Motherboard.objects.all()
    return render(request,'admin/edit_ram.html',{'data':r,'data1':ca,'data2':mo})

def edit_rampost(request):
    id = request.POST['id']
    category = request.POST['select']
    name = request.POST['textfield']
    select = request.POST['select2']

    details = request.POST['textarea']
    price = request.POST['textfield2']

    obj = Ram.objects.get(id=id)
    if 'fileField' in request.FILES:
        photo = request.FILES['fileField']

        fs = FileSystemStorage()
        date = datetime.now().strftime("%Y%m%d-%H%M%S") + '.jpg'
        fs.save(date, photo)
        path = fs.url(date)

        obj.photo = path
        obj.details = details
        obj.price = price
        obj.name = name
        obj.CATEGORY_id = category
        obj.Motherboard_id = select
        obj.save()

    obj.details = details
    obj.price = price
    obj.name = name
    obj.CATEGORY_id = category
    obj.Motherboard_id = select
    obj.save()

    return HttpResponse("<script>alert('UPDATED'); window.location='/myapp/view_ram/'</script>")


def delete_ram(request, id):
    d = Ram.objects.filter(id=id).delete()
    return redirect('/myapp/view_ram/')


def search_ram(request):
    s = request.POST['textfield']
    obj = Ram.objects.filter(name__icontains=s)
    return render(request, 'admin/view_ram.html', {'data': obj})

def edit_smps(request,id):
    ed = Smps.objects.get(id=id)
    ca = Category.objects.all()
    mo = Motherboard.objects.all()
    return render(request,'admin/edit_smps.html',{'data':ed,'data1':ca,'data2':mo})
def edit_smpspost(request):
    category = request.POST['select']
    name = request.POST['textfield']

    details = request.POST['textarea']
    select = request.POST['select2']
    id = request.POST['id']
    price = request.POST['textfield2']
    obj = Smps.objects.get(id=id)

    if 'fileField' in request.FILES:
        photo = request.FILES['fileField']

        fs = FileSystemStorage()
        date = datetime.now().strftime("%Y%m%d-%H%M%S") + '.jpg'
        fs.save(date, photo)
        path = fs.url(date)
        obj.photo = path
        obj.details = details
        obj.price = price
        obj.name = name
        obj.CATEGORY_id = category
        obj.Motherboard_id = select
        obj.save()

    obj.details = details
    obj.price = price
    obj.name = name
    obj.CATEGORY_id = category
    obj.Motherboard_id = select
    obj.save()

    return HttpResponse("<script>alert('UPDATED'); window.location='/myapp/view_smps/'</script>")
def delete_smps(request,id):
    d=Smps.objects.filter(id=id).delete()
    return redirect('/myapp/view_smps/')

def search_smps(request):
    c=request.POST['textfield']
    obj = Smps.objects.filter(name__icontains=c)
    return render(request, 'admin/view_smps.html', {'data': obj})



def edit_storage(request,id):
    ed = Storage.objects.get(id=id)
    ca = Category.objects.all()
    mo = Motherboard.objects.all()
    return render(request,'admin/edit_storage.html',{'data':ed,'data1':ca,'data2':mo})
def edit_storagepost(request):
    category = request.POST['select']
    name = request.POST['textfield']

    details = request.POST['textarea']
    select = request.POST['select2']
    id = request.POST['id']
    price = request.POST['textfield2']
    obj = Storage.objects.get(id=id)

    if 'fileField' in request.FILES:
        photo = request.FILES['fileField']

        fs = FileSystemStorage()
        date = datetime.now().strftime("%Y%m%d-%H%M%S") + '.jpg'
        fs.save(date, photo)
        path = fs.url(date)
        obj.photo = path
        obj.details = details
        obj.price = price
        obj.name = name
        obj.CATEGORY_id = category
        obj.Motherboard_id = select
        obj.save()

    obj.details = details
    obj.price = price
    obj.name = name
    obj.CATEGORY_id = category
    obj.Motherboard_id = select
    obj.save()

    return HttpResponse("<script>alert('UPDATED'); window.location='/myapp/view_storage/'</script>")
def delete_storage(request,id):
    d=Storage.objects.filter(id=id).delete()
    return redirect('/myapp/view_storage/')
def search_storage(request):
    s=request.POST['textfield']
    obj = Storage.objects.filter(name__icontains=s)
    return render(request, 'admin/view_storage.html', {'data': obj})



def edit_subcategory(request):
    return render(request,'admin/edit_subcategory.html')

def edit_subcategorypost(request):
    add_sub_name = request.POST['textfield']
    return HttpResponse("ok")

def from_cart_buy_product(request):
    return render(request,'admin/from_cart_buy product.html')

def view_assigened_order_and_status(request):
    ob=Assign.objects.all()
    return render(request,'admin/view_assigned_0rder-and_status.html',{'data':ob})

def view_cabnet(request):
    obj=Cabinet.objects.all()
    return render(request,'admin/view_cabnet.html',{'data':obj})

def view_category(request):
    obj=Category.objects.all()
    return render(request,'admin/view_category.html',{'data':obj})
def delete_category(request,id):
    d=Category.objects.filter(id=id).delete()
    return redirect('/myapp/view_category/')

def view_company_detail(request):
    objs = Shop.objects.all()[0]
    return render(request,'admin/view_comapany_detail.html',{'dat':objs})

def view_cooler(request):
    obj=Cooler.objects.all()
    return render(request,'admin/view_cooler.html',{'data':obj})

def view_deliveryboy(request):
    ob=Deliveryboy.objects.all()
    return render(request,'admin/view_deliveryboy.html',{'data':ob})

def view_graphics(request):
    obj=Graphicscard.objects.all()
    return render(request,'admin/view_graphics.html',{'data':obj})

def view_keyboard(request):
    obj=Keyboard.objects.all()
    return render(request,'admin/view_keyboard.html',{'data':obj})

def view_monitor(request):
    obj=Monitor.objects.all()
    return render(request,'admin/view_monitor.html',{'data':obj})

def view_motherboard(request):
    obj=Motherboard.objects.all()
    return render(request,'admin/view_motherboard.html',{'data':obj})

def view_orders_reject_reason(request):
    return render(request,'admin/view_orders_(reject_reason).html')

def admin_view_orders(request):
    orders = Order_main.objects.all()
    order_assignments = []

    for order in orders:
        assignment = Assign.objects.filter(ORDERMAIN_ID=order.id).first()
        order_assignments.append({
            'order': order,
            'assign_status': assignment.status if assignment else None
        })

    return render(request, 'admin/view_orders.html', {'order_assignments': order_assignments})


def view_orders_and_assign(request,id):
    a = Order_sub.objects.filter(ORDERMAIN_ID__type="assemble",ORDERMAIN_ID_id=id)
    l = []
    for i in a:

        if i.type == "MOTHERBOARD" or i.type == "MOTHERBOARD_assm":
            name = Motherboard.objects.get(id=i.particularid).motherboardname
            l.append({
                'id': i.id,
                'quantity': i.quantity,
                'price': i.price,
                'particularid': i.particularid,
                'date': i.ORDERMAIN_ID.date,
                'ammount': i.ORDERMAIN_ID.ammount,
                'status': i.ORDERMAIN_ID.status,
                'omid': i.ORDERMAIN_ID.id,
                'uname': i.ORDERMAIN_ID.USERID.name,
                'name': name
            })
        if i.type == "RAM" or i.type == "RAM_assm":
            name = Ram.objects.get(id=int(i.particularid)).name
            l.append({
                'id': i.id,
                'quantity': i.quantity,
                'price': i.price,
                'particularid': i.particularid,
                'date': i.ORDERMAIN_ID.date,

                'omid': i.ORDERMAIN_ID.id,
                'ammount': i.ORDERMAIN_ID.ammount,
                'status': i.ORDERMAIN_ID.status,
                'uname': i.ORDERMAIN_ID.USERID.name,
                'name': name
            })
        if i.type == "PROCESSOR" or i.type == "PROCESSOR_assm":
            name = Processor.objects.get(id=int(i.particularid)).NAME
            l.append({
                'id': i.id,
                'quantity': i.quantity,
                'price': i.price,
                'particularid': i.particularid,
                'omid':i.ORDERMAIN_ID.id,
                'date': i.ORDERMAIN_ID.date,
                'ammount': i.ORDERMAIN_ID.ammount,
                'status': i.ORDERMAIN_ID.status,
                'uname': i.ORDERMAIN_ID.USERID.name,
                'name': name
            })
        if i.type == "STORAGE" or i.type == "STORAGE_assm":
            name = Storage.objects.get(id=int(i.particularid)).name
            l.append({
                'id': i.id,
                'quantity': i.quantity,
                'price': i.price,
                'particularid': i.particularid,
                'omid':i.ORDERMAIN_ID.id,
                'date': i.ORDERMAIN_ID.date,
                'ammount': i.ORDERMAIN_ID.ammount,
                'status': i.ORDERMAIN_ID.status,
                'uname': i.ORDERMAIN_ID.USERID.name,
                'name': name
            })
        if i.type == "GRAPHICSCARD" or i.type == "GRAPHICSCARD_assm":
            name = Graphicscard.objects.get(id=int(i.particularid)).name
            l.append({
                'id': i.id,
                'quantity': i.quantity,
                'price': i.price,
                'particularid': i.particularid,
                'omid':i.ORDERMAIN_ID.id,
                'date': i.ORDERMAIN_ID.date,
                'ammount': i.ORDERMAIN_ID.ammount,
                'status': i.ORDERMAIN_ID.status,
                'uname': i.ORDERMAIN_ID.USERID.name,
                'name': name
            })
        if i.type == "SMPS" or i.type == "SMPS_assm":
            name = Smps.objects.get(id=int(i.particularid)).name
            l.append({
                'id': i.id,
                'quantity': i.quantity,
                'price': i.price,
                'particularid': i.particularid,
                'omid':i.ORDERMAIN_ID.id,
                'date': i.ORDERMAIN_ID.date,
                'ammount': i.ORDERMAIN_ID.ammount,
                'status': i.ORDERMAIN_ID.status,
                'uname': i.ORDERMAIN_ID.USERID.name,
                'name': name
            })
        if i.type == "CABINET" or i.type == "CABINET_assm":
            name = Cabinet.objects.get(id=int(i.particularid)).name
            l.append({
                'id': i.id,
                'quantity': i.quantity,
                'price': i.price,
                'particularid': i.particularid,
                'omid':i.ORDERMAIN_ID.id,
                'date': i.ORDERMAIN_ID.date,
                'ammount': i.ORDERMAIN_ID.ammount,
                'status': i.ORDERMAIN_ID.status,
                'uname': i.ORDERMAIN_ID.USERID.name,
                'name': name
            })
        if i.type == "MONITOR" or i.type == "MONITOR_assm":
            name = Monitor.objects.get(id=int(i.particularid)).name
            l.append({
                'id': i.id,
                'quantity': i.quantity,
                'price': i.price,
                'particularid': i.particularid,
                'omid':i.ORDERMAIN_ID.id,
                'date': i.ORDERMAIN_ID.date,
                'ammount': i.ORDERMAIN_ID.ammount,
                'status': i.ORDERMAIN_ID.status,
                'uname': i.ORDERMAIN_ID.USERID.name,
                'name': name
            })
        if i.type == "COOLER" or i.type == "COOLER_assm":
            name = Cooler.objects.get(id=int(i.particularid)).name
            l.append({
                'id': i.id,
                'quantity': i.quantity,
                'price': i.price,
                'particularid': i.particularid,
                'omid':i.ORDERMAIN_ID.id,
                'date': i.ORDERMAIN_ID.date,
                'ammount': i.ORDERMAIN_ID.ammount,
                'status': i.ORDERMAIN_ID.status,
                'uname': i.ORDERMAIN_ID.USERID.name,
                'name': name
            })
    return render(request,'admin/view_orders_and_assign.html',{"data":l})
def acceptuserorder(request,id):
    Order_main.objects.filter(id=id).update(status="Approved")
    return HttpResponse("<script>alert('APPROVED'); window.location='/myapp/admin_view_orders/'</script>")
def rejectuserorder(request,id):
    Order_main.objects.filter(id=id).update(status="Rejected")
    return HttpResponse("<script>alert('REJECTED'); window.location='/myapp/admin_view_orders/'</script>")

def view_processor(request):
    obj=Processor.objects.all()
    return render(request,'admin/view_processor.html',{'data':obj})

def view_ram(request):
    obj=Ram.objects.all()
    return render(request,'admin/view_ram.html',{'data':obj})

def view_smps(request):
    obj=Smps.objects.all()
    return render(request,'admin/view_smps.html',{'data':obj})

def view_storage(request):
    obj=Storage.objects.all()
    return render(request,'admin/view_storage.html',{'data':obj})

def view_subcategory(request):
    return render(request,'admin/view_subcategory.html')

def assigned_order_delivery_reject_status(request):
    return render(request,'deliveryboy/assigned_order_delevery_Reject_ststus.html')

def assigned_order_delevery_ststus(request,id):
    a=Assign.objects.get(id=id)
    return render(request,'deliveryboy/assigned_order_delevery_ststus.html',{'data':a})


def assigned_order_delevery_ststus_post(request):
    id=request.POST['id']
    status=request.POST['status']
    a=Assign.objects.get(id=id)

    delivery_boy = a.DELIVERYBOY_ID
    delivery_boy.status = True
    delivery_boy.save()

    a.status=status
    a.save()
    return HttpResponse('''<script>alert('Updated');window.location='/myapp/view_assigned_order_and_take_order/'</script>''')

def assigned_order_delivery_delivery_statuspost(request):
    otp=request.POST['textfield']
    return HttpResponse("ok")

def edit_deliveryboy_profile(request):
    obj=Deliveryboy.objects.get(LOGIN_id=request.session['lid'])
    return render(request,'deliveryboy/edit_deliveryboy_profile.html',{"data":obj})

def edit_deliveryboy_profilepost(request):
    name=request.POST['textfield']
    dob=request.POST['textfield2']
    place=request.POST['textfield3']
    pincode=request.POST['textfield4']
    post=request.POST['textfield5']
    district=request.POST['textfield6']
    phonenumber=request.POST['textfield7']
    street=request.POST['textfield8']

    ob = Deliveryboy.objects.get(LOGIN=request.session["lid"])
    ob.name=name
    ob.district=district
    ob.dob=dob
    ob.street=street
    ob.place=place
    ob.post=post
    ob.phonenumber=phonenumber
    ob.pincode=pincode
    ob.save()


    return HttpResponse("ok")

def view_assigned_order_and_take_order(request):
    ob=Assign.objects.filter(DELIVERYBOY_ID__LOGIN_id=request.session['lid'])
    return render(request,'deliveryboy/view_assigned_order_and _take_order.html',{'data':ob})

def view_deliveryboy_profile(request):
    res = Deliveryboy.objects.get(LOGIN=request.session['lid'])
    return render(request,'deliveryboy/view_deliveryboy_profile.html',{'data':res})

def deliveryboy_changepassword(request):
    return render(request,'deliveryboy/deliverboy_changepassword.html')
def deliveryboy_changepasswordpost(request):
    currentpassword=request.POST['textfield']
    newpassword=request.POST['textfield2']
    reenterpassword=request.POST['textfield3']
    return HttpResponse('ok')

def edit_user_profile(request):
    res = Register.objects.get(LOGIN=request.session['lid'])
    return render(request,'user/edit_user_profile.html',{'data':res})
def edit_user_profilepost(request):
    name=request.POST['textfield']
    dob=request.POST['textfield2']
    place=request.POST['textfield3']
    pin=request.POST['textfield4']
    post=request.POST['textfield5']
    district=request.POST['textfield6']
    phonenumber=request.POST['textfield7']
    email=request.POST['textfield8']
    ob=Register.objects.get(LOGIN=request.session["lid"])
    ob.name=name
    ob.dob=dob
    ob.place=place
    ob.pin=pin
    ob.post=post
    ob.district=district
    ob.phonenumber=phonenumber
    ob.email=email
    ob.save()


    return HttpResponse("ok")

def order_product_cart(request):
    return render(request,'user/order_product_cart.html')
def order_product_cartpost(request):
    quantity=request.POST['select']
    return HttpResponse('Ok')

def select_assemble_or_orderproduct(request):
    return render(request,'user/select_aeemble_or_orderproduct.html')

def select_any_product(request):
    return render(request,'user/select_any_product.html')


def select_cabnet(request):
    obj = Cabinet.objects.all()
    return render(request,'user/select_cabnet.html',{'data':obj})

def search_select_cabnet(request):
    s=request.POST['textfield']
    obj = Cabinet.objects.filter(name__icontains=s)
    return render(request, 'user/select_cabnet.html', {'data': obj})

def addtocart_cabnet(request):
    qnt=request.POST['textfield2']
    print(qnt,"hhhhhhhhhhhhhhhh")
    pid = request.POST['pid']
    print(pid)
    ob = Cabinet.objects.get(id=pid)
    amt = int(qnt) * int(ob.price)

    ca = Cart()
    ca.quantity = qnt
    ca.particularid = pid
    ca.type = 'CABINET'
    ca.price=amt
    ca.USERID = Register.objects.get(LOGIN_id=request.session['lid'])
    ca.save()
    return HttpResponse("<script>alert('Added succesfully'); window.location='/myapp/select_any_product/'</script>")



def select_category(request):
    return render(request,'user/select_category.html')

def select_cooler(request):
    obj = Cooler.objects.all()
    return render(request,'user/select_cooler.html',{'data':obj})
def search_select_cooler(request):
    s=request.POST['textfield']
    obj = Cooler.objects.filter(name__icontains=s)
    return render(request, 'user/select_cooler.html', {'data': obj})
def addtocart_cooler(request):
    qnt=request.POST['textfield2']
    pid=request.POST['pid']


    ob=Cooler.objects.get(id=pid)
    amt=int(qnt)*int(ob.price)

    ca=Cart()
    ca.quantity=qnt
    ca.particularid=pid
    ca.type='COOLER'
    ca.price=amt
    ca.USERID = Register.objects.get(LOGIN_id=request.session['lid'])
    ca.save()

    return HttpResponse("<script>alert('Added succesfully'); window.location='/myapp/select_any_product/'</script>")

def select_fan(request):
    return render(request,'user/select_fan.html')

def select_graphicscard(request):
    obj = Graphicscard.objects.all()
    return render(request,'user/select_graphicscard.html',{'data':obj})
def search_select_graphicscard(request):
    s=request.POST['textfield']
    obj = Graphicscard.objects.filter(name__icontains=s)
    return render(request, 'user/select_graphicscard.html', {'data': obj})
def addtocart_graphicscard(request):
    qnt=request.POST['textfield2']
    pid=request.POST['pid']

    ca=Cart()
    ca.quantity=qnt
    ca.particularid=pid
    ca.type='GRAPHICSCARD'
    ca.USERID = Register.objects.get(LOGIN_id=request.session['lid'])
    ca.save()

    return HttpResponse("<script>alert('Added succesfully'); window.location='/myapp/select_any_product/'</script>")

def select_keyboard(request):
    obj = Keyboard.objects.all()
    return render(request,'user/select_keyboard.html',{'data':obj})
def search_select_keyboard(request):
    s=request.POST['textfield']
    obj = Keyboard.objects.filter(name__icontains=s)
    return render(request, 'user/select_keyboard.html', {'data': obj})
def addtocart_keyboard(request):
    qnt=request.POST['textfield2']
    pid=request.POST['pid']

    ob = Keyboard.objects.get(id=pid)
    amt = int(qnt) * int(ob.price)

    ca=Cart()
    ca.quantity=qnt
    ca.particularid=pid
    ca.type='KEYBOARD'
    ca.price=amt
    ca.USERID = Register.objects.get(LOGIN_id=request.session['lid'])
    ca.save()

    return HttpResponse("<script>alert('Added succesfully'); window.location='/myapp/select_any_product/'</script>")

def select_monitor(request):
    obj = Monitor.objects.all()
    return render(request,'user/select_monitor.html',{'data':obj})
def search_select_monitor(request):
    s=request.POST['textfield']
    obj = Monitor.objects.filter(motherboardname__icontains=s)
    return render(request, 'user/select_monitor.html', {'data': obj})
def addtocart_selectmonitor(request):
    qnt=request.POST['textfield2']
    pid=request.POST['pid']
    ob = Monitor.objects.get(id=pid)
    amt = int(qnt) * int(ob.price)

    ca=Cart()
    ca.quantity=qnt
    ca.particularid=pid
    ca.type='MONITOR'
    ca.price=amt
    ca.USERID = Register.objects.get(LOGIN_id=request.session['lid'])
    ca.save()

    return HttpResponse("<script>alert('Added succesfully'); window.location='/myapp/select_any_product/'</script>")

def select_motherboard(request):
    obj = Motherboard.objects.all()
    return render(request,'user/select_motherboard.html',{'data':obj})
def search_select_motherboard(request):
    s=request.POST['textfield']
    obj = Motherboard.objects.filter(motherboardname__icontains=s)
    return render(request, 'user/select_motherboard.html', {'data': obj})

def addtocart_selectmotherboard(request):
    qnt=request.POST['textfield2']
    pid=request.POST['pid']
    print(qnt,"sdgfhjrtyuicxv")

    ob = Motherboard.objects.get(id=pid)
    amt = int(qnt) * int(ob.price)

    ca=Cart()
    ca.quantity=qnt
    ca.particularid=pid
    ca.type='MOTHERBOARD'
    ca.price=amt
    ca.USERID = Register.objects.get(LOGIN_id=request.session['lid'])
    ca.save()

    return HttpResponse("<script>alert('Added succesfully'); window.location='/myapp/select_any_product/'</script>")



def select_mouse(request):
    return render(request,'user/select_mouse.html')

def select_processor(request):
    obj = Processor.objects.all()
    return render(request,'user/select_processor.html',{'data':obj})
def search_select_procssor(request):
    s=request.POST['textfield']
    obj = Processor.objects.filter(name__icontains=s)
    return render(request, 'user/select_processor.html', {'data': obj})
def addtocart_procesor(request):
    qnt=request.POST['textfield2']
    pid=request.POST['pid']
    ob = Processor.objects.get(id=pid)
    amt = int(qnt) * int(ob.price)

    ca=Cart()
    ca.quantity=qnt
    ca.particularid=pid
    ca.type='PROCESSOR'
    ca.price=amt
    ca.USERID = Register.objects.get(LOGIN_id=request.session['lid'])
    ca.save()

    return HttpResponse("<script>alert('Added succesfully'); window.location='/myapp/select_any_product/'</script>")

def select_ram(request):
    obj = Ram.objects.all()
    return render(request,'user/select_ram.html',{'data':obj})
def search_select_ram(request):
    s=request.POST['textfield']
    obj = Ram.objects.filter(name__icontains=s)
    return render(request, 'user/select_ram.html', {'data': obj})
def addtocart_ram(request):


    qnt=request.POST['textfield2']
    pid=request.POST['pid']

    ob = Ram.objects.get(id=pid)
    amt = int(qnt) * int(ob.price)

    ca=Cart()
    ca.quantity=qnt
    ca.particularid=pid
    ca.type='RAM'
    ca.price=amt
    ca.USERID = Register.objects.get(LOGIN_id=request.session['lid'])
    ca.save()

    return HttpResponse("<script>alert('Added succesfully'); window.location='/myapp/select_any_product/'</script>")




def select_smps(request):
    obj = Smps.objects.all()
    return render(request,'user/select_smps.html',{'data':obj})
def search_select_smps(request):
    s=request.POST['textfield']
    obj = Smps.objects.filter(name__icontains=s)
    return render(request, 'user/select_smps.html', {'data': obj})
def addtocart_smps(request):
    qnt=request.POST['textfield2']
    pid=request.POST['pid']

    ob = Smps.objects.get(id=pid)
    amt = int(qnt) * int(ob.price)

    ca=Cart()
    ca.quantity=qnt
    ca.particularid=pid
    ca.type='SMPS'
    ca.price=amt
    ca.USERID = Register.objects.get(LOGIN_id=request.session['lid'])
    ca.save()

    return HttpResponse("<script>alert('Added succesfully'); window.location='/myapp/select_any_product/'</script>")

def select_storage(request):
    obj = Storage.objects.all()
    return render(request,'user/select_storage.html',{'data':obj})
def search_select_storage(request):
    s=request.POST['textfield']
    obj = Storage.objects.filter(name__icontains=s)
    return render(request, 'user/select_storage.html', {'data': obj})
def addtocart_storage(request):
    qnt=request.POST['textfield2']
    pid=request.POST['pid']
    ob = Storage.objects.get(id=pid)
    amt = int(qnt) * int(ob.price)

    ca=Cart()
    ca.quantity=qnt
    ca.particularid=pid
    ca.type='STORAGE'
    ca.price=amt
    ca.USERID = Register.objects.get(LOGIN_id=request.session['lid'])
    ca.save()

    return HttpResponse("<script>alert('Added succesfully'); window.location='/myapp/select_any_product/'</script>")

def user_buy_assembleproduct(request):
    m = Motherboard.objects.filter( price__lte=19999)
    return render(request,'user/user_buy_assembleproduct.html',{'data':m})
def addtocart_assemblemotherboard(request):

    pid=request.POST['pid']

    request.session["mid"]=pid

    ob = Motherboard.objects.get(id=pid)
    amt = 1 * int(ob.price)

    ca=Cart()
    ca.quantity=1
    ca.particularid=pid
    ca.type='MOTHERBOARD_assm'
    ca.price=amt
    ca.USERID = Register.objects.get(LOGIN_id=request.session['lid'])
    ca.save()

    return HttpResponse("<script>alert('Motherboard Added succesfully'); window.location='/myapp/user_assemble_ram/'</script>")

def user_assemble_ram(request):
    m=Ram.objects.filter(Motherboard_id=request.session["mid"])
    return render(request,'user/user_assemble_ram.html',{'data':m})


def addtocart_assembleram(request):

    pid=request.POST['pid']

    ob = Ram.objects.get(id=pid)
    amt = 1 * int(ob.price)

    ca = Cart()
    ca.quantity = 1
    ca.particularid = pid
    ca.type = 'RAM_assm'
    ca.price=amt
    ca.USERID = Register.objects.get(LOGIN_id=request.session['lid'])
    ca.save()

    # ca=Cart()
    # ca.quantity=qnt
    # ca.particularid=pid
    return HttpResponse("<script>alert('Ram Added succesfully'); window.location='/myapp/user_assemble_processor/'</script>")

def user_assemble_processor(request):
    m=Processor.objects.filter(Motherboard_id=request.session["mid"])
    return render(request,'user/user_assemble_processor.html',{'data':m})
def addtocart_assembleprocessor(request):

    pid=request.POST['pid']
    ob = Processor.objects.get(id=pid)
    amt = 1 * int(ob.price)

    ca=Cart()
    ca.quantity=1
    ca.particularid=pid
    ca.type='PROCESSOR_assm'
    ca.price=amt
    ca.USERID = Register.objects.get(LOGIN_id=request.session['lid'])
    ca.save()

    return HttpResponse("<script>alert('Processor Added succesfully'); window.location='/myapp/user_assemble_storage/'</script>")

def user_assemble_storage(request):
    m=Storage.objects.filter(Motherboard_id=request.session["mid"])
    return render(request,'user/user_assemble_storage.html',{'data':m})
def addtocart_assemblestorage(request):

    pid=request.POST['pid']
    ob = Storage.objects.get(id=pid)
    amt = 1 * int(ob.price)

    ca=Cart()
    ca.quantity=1
    ca.particularid=pid
    ca.type='STORAGE_assm'
    ca.price=amt
    ca.USERID = Register.objects.get(LOGIN_id=request.session['lid'])
    ca.save()

    return HttpResponse("<script>alert('Strorage Added succesfully'); window.location='/myapp/user_assemble_graphics/'</script>")

def user_assemble_graphics(request):
    m=Graphicscard.objects.filter(Motherboard_id=request.session["mid"])
    return render(request,'user/user_assemble_graphics.html',{'data':m})
def addtocart_assemblegraphics(request):

    pid=request.POST['pid']

    ob = Graphicscard.objects.get(id=pid)
    amt = 1 * int(ob.price)

    ca=Cart()
    ca.quantity=1
    ca.particularid=pid
    ca.type='GRAPHICSCARD_assm'
    ca.price=amt
    ca.USERID = Register.objects.get(LOGIN_id=request.session['lid'])
    ca.save()

    return HttpResponse("<script>alert('Graphicscard Added succesfully'); window.location='/myapp/user_assemble_smps/'</script>")

def user_assemble_smps(request):
    m=Smps.objects.filter(Motherboard_id=request.session["mid"])
    return render(request,'user/user_assemble_smps.html',{'data':m})
def addtocart_assemblesmps(request):

    pid=request.POST['pid']
    ob = Smps.objects.get(id=pid)
    amt = 1 * int(ob.price)

    ca=Cart()
    ca.quantity=1
    ca.particularid=pid
    ca.type='SMPS_assm'
    ca.price=amt
    ca.USERID = Register.objects.get(LOGIN_id=request.session['lid'])
    ca.save()

    return HttpResponse("<script>alert('Smps Added succesfully'); window.location='/myapp/user_assemble_cabinet/'</script>")


def user_assemble_cabinet(request):
    m=Cabinet.objects.filter(Motherboard_id=request.session["mid"])
    return render(request,'user/user_assemble_Cabinet.html',{'data':m})
def addtocart_assemble_cabinet(request):

    pid=request.POST['pid']
    ob = Cabinet.objects.get(id=pid)
    amt = 1 * int(ob.price)

    ca=Cart()
    ca.quantity=1
    ca.particularid=pid
    ca.type='CABINET_assm'
    ca.price=amt
    ca.USERID = Register.objects.get(LOGIN_id=request.session['lid'])
    ca.save()

    return HttpResponse("<script>alert('Cabnet Added succesfully'); window.location='/myapp/user_assemble_monitor/'</script>")

def user_assemble_monitor(request):
    m=Monitor.objects.filter(Motherboard_id=request.session["mid"])
    return render(request,'user/user_assemble_monitor.html',{'data':m})
def addtocart_assemble_monitor(request):

    pid=request.POST['pid']
    ob = Monitor.objects.get(id=pid)
    amt = 1 * int(ob.price)

    ca=Cart()
    ca.quantity=1
    ca.particularid=pid
    ca.type='MONITOR_assm'
    ca.price=amt
    ca.USERID = Register.objects.get(LOGIN_id=request.session['lid'])
    ca.save()

    return HttpResponse("<script>alert('Monitor Added succesfully'); window.location='/myapp/user_assemble_cooler/'</script>")

def user_assemble_cooler(request):
    m=Cooler.objects.all()
    return render(request,'user/user_assemble_cooler.html',{'data':m})
def addtocart_assemble_cooler(request):

    pid=request.POST['pid']
    ob = Cooler.objects.get(id=pid)
    amt = 1 * int(ob.price)

    ca=Cart()
    ca.quantity=1
    ca.particularid=pid
    ca.type='COOLER_assm'
    ca.price=amt
    ca.USERID = Register.objects.get(LOGIN_id=request.session['lid'])
    ca.save()

    return HttpResponse("<script>alert('Cooler Added succesfully'); window.location='/myapp/view_cart/'</script>")






def user_buy_assembleproduct_inter(request):
    m = Motherboard.objects.filter(price__gte=20000, price__lte=30000)
    return render(request,'user/user_buy_assembleproduct_inter.html',{'data':m})




def addtocart_assemblemotherboard_inter(request):


    pid=request.POST['pid']

    request.session["mid"]=pid
    ob = Motherboard.objects.get(id=pid)
    amt = 1 * int(ob.price)

    ca=Cart()
    ca.price = amt
    ca.quantity=1
    ca.particularid=pid
    ca.type='MOTHERBOARD_assm'

    ca.USERID=Register.objects.get(LOGIN_id=request.session['lid'])
    ca.save()

    return HttpResponse("<script>alert('Motherboard Added succesfully'); window.location='/myapp/user_assemble_ram_inter/'</script>")

def user_assemble_ram_inter(request):
    m=Ram.objects.filter(Motherboard_id=request.session["mid"])
    return render(request,'user/user_assemble_ram_inter.html',{'data':m})
def addtocart_assembleram_inter(request):

    pid=request.POST['pid']
    ob = Ram.objects.get(id=pid)
    amt = 1 * int(ob.price)

    ca = Cart()
    ca.price = amt
    ca.quantity = 1
    ca.particularid = pid
    ca.type = 'RAM_assm'
    ca.USERID = Register.objects.get(LOGIN_id=request.session['lid'])
    ca.save()

    # ca=Cart()
    # ca.quantity=qnt
    # ca.particularid=pid
    return HttpResponse("<script>alert('Ram Added succesfully'); window.location='/myapp/user_assemble_processor_inter/'</script>")

def user_assemble_processor_inter(request):
    m=Processor.objects.filter(Motherboard_id=request.session["mid"])
    return render(request,'user/user_assemble_processor_inter.html',{'data':m})
def addtocart_assembleprocessor_inter(request):

    pid=request.POST['pid']
    ob = Processor.objects.get(id=pid)
    amt = 1 * int(ob.price)

    ca = Cart()
    ca.price = amt
    ca.quantity=1
    ca.particularid=pid
    ca.USERID = Register.objects.get(LOGIN_id=request.session['lid'])
    ca.type='PROCESSOR_assm'
    ca.save()

    return HttpResponse("<script>alert('Processor Added succesfully'); window.location='/myapp/user_assemble_storage_inter/'</script>")

def user_assemble_storage_inter(request):
    m=Storage.objects.filter(Motherboard_id=request.session["mid"])
    return render(request,'user/user_assemble_storage_inter.html',{'data':m})
def addtocart_assemblestorage_inter(request):

    pid=request.POST['pid']

    ob = Storage.objects.get(id=pid)
    amt = 1 * int(ob.price)

    ca = Cart()
    ca.price = amt
    ca.quantity=1
    ca.particularid=pid
    ca.USERID = Register.objects.get(LOGIN_id=request.session['lid'])
    ca.type='STORAGE_assm'
    ca.save()

    return HttpResponse("<script>alert('Strorage Added succesfully'); window.location='/myapp/user_assemble_graphics_inter/'</script>")

def user_assemble_graphics_inter(request):
    m=Graphicscard.objects.filter(Motherboard_id=request.session["mid"])
    return render(request,'user/user_assemble_graphics_inter.html',{'data':m})
def addtocart_assemblegraphics_inter(request):

    pid=request.POST['pid']

    ob = Graphicscard.objects.get(id=pid)
    amt = 1 * int(ob.price)

    ca = Cart()
    ca.price = amt
    ca.quantity=1
    ca.particularid=pid
    ca.USERID = Register.objects.get(LOGIN_id=request.session['lid'])
    ca.type='GRAPHICSCARD_assm'
    ca.save()

    return HttpResponse("<script>alert('Graphicscard Added succesfully'); window.location='/myapp/user_assemble_smps_inter/'</script>")

def user_assemble_smps_inter(request):
    m=Smps.objects.filter(Motherboard_id=request.session["mid"])
    return render(request,'user/user_assemble_smps_inter.html',{'data':m})
def aaddtocart_assemblesmps_inter(request):

    pid=request.POST['pid']

    ob = Smps.objects.get(id=pid)
    amt = 1 * int(ob.price)

    ca = Cart()
    ca.price = amt
    ca.quantity=1
    ca.particularid=pid
    ca.USERID = Register.objects.get(LOGIN_id=request.session['lid'])
    ca.type='SMPS_assm'
    ca.save()

    return HttpResponse("<script>alert('Smps Added succesfully'); window.location='/myapp/user_assemble_cabinet_inter/'</script>")


def user_assemble_cabinet_inter(request):
    m=Cabinet.objects.filter(Motherboard_id=request.session["mid"])
    return render(request,'user/user_assemble_cabinet_inter.html',{'data':m})
def addtocart_assemble_cabinet_inter(request):

    pid=request.POST['pid']

    ob = Cabinet.objects.get(id=pid)
    amt = 1 * int(ob.price)

    ca = Cart()
    ca.price = amt
    ca.quantity=1
    ca.particularid=pid
    ca.USERID = Register.objects.get(LOGIN_id=request.session['lid'])
    ca.type='CABINET_assm'
    ca.save()

    return HttpResponse("<script>alert('Cabnet Added succesfully'); window.location='/myapp/user_assemble_monitor_inter/'</script>")

def user_assemble_monitor_inter(request):
    m=Monitor.objects.filter(Motherboard_id=request.session["mid"])
    return render(request,'user/user_assemble_monitor_inter.html',{'data':m})
def addtocart_assemble_monitor_inter(request):

    pid=request.POST['pid']

    ob = Monitor.objects.get(id=pid)
    amt = 1 * int(ob.price)

    ca = Cart()
    ca.price = amt
    ca.quantity=1
    ca.particularid=pid
    ca.USERID = Register.objects.get(LOGIN_id=request.session['lid'])
    ca.type='MONITOR_assm'
    ca.save()

    return HttpResponse("<script>alert('Monitor Added succesfully'); window.location='/myapp/user_assemble_cooler_inter/'</script>")

def user_assemble_cooler_inter(request):
    m=Cooler.objects.all()
    return render(request,'user/user_assemble_cooler_inter.html',{'data':m})
def addtocart_assemble_cooler_inter(request):

    pid=request.POST['pid']

    ob = Cooler.objects.get(id=pid)
    amt = 1 * int(ob.price)

    ca = Cart()
    ca.price = amt
    ca.quantity=1
    ca.particularid=pid
    ca.USERID = Register.objects.get(LOGIN_id=request.session['lid'])
    ca.type='COOLER_assm'
    ca.save()

    return HttpResponse("<script>alert('Cooler Added succesfully'); window.location='/myapp/view_cart/'</script>")

def cahange_password(request):
    return render(request,'user/user_changepassword.html')
def cahange_passwordpost(request):
    currentpassword = request.POST['textfield']
    newpassword = request.POST['textfield2']
    reenterpassword = request.POST['textfield3']
    return HttpResponse("ok")

def user_home(request):
    return render(request,'user/user_home.html')


def user_register(request):
    return render(request,'user/user_register.html')
def user_registerpost(request):
    name=request.POST['textfield']
    email = request.POST['textfield8']
    dob=request.POST['textfield2']
    gender=request.POST['radio']
    place=request.POST['textfield3']
    pin=request.POST['textfield4']
    post=request.POST['textfield5']
    district=request.POST['textfield6']
    phonenumber=request.POST['textfield7']

    lobj=Login()
    lobj.username=email
    lobj.password=phonenumber
    lobj.type='user'
    lobj.save()

    robj=Register()
    robj.name=name
    robj.email=email
    robj.dob=dob
    robj.gender=gender
    robj.place=place
    robj.pin=pin
    robj.post=post
    robj.district=district
    robj.phonenumber=phonenumber
    robj.LOGIN=lobj

    robj.save()

    return HttpResponse("<script>alert('Added successfully');window.location='/myapp/login/'</script>")

def view_cart(request):
    obj = Cart.objects.filter(USERID__LOGIN=request.session["lid"])
    totalamount = 0
    for i in obj:
        totalamount = totalamount + int(i.price)
    totalamount = totalamount + 2500
    data = []
    for i2 in obj:
        if i2.type == "COOLER_assm":
            a = Cooler.objects.get(id=i2.particularid)
            row = {"pname": a.name, "qty": i2.quantity, "amount": i2.price, "id": i2.id}
            data.append(row)
        elif i2.type == "COOLER":
            a = Cooler.objects.get(id=i2.particularid)
            row = {"pname": a.name, "qty": i2.quantity, "amount": i2.price, "id": i2.id}
            data.append(row)

        elif i2.type == "RAM_assm":
            a = Ram.objects.get(id=i2.particularid)
            row = {"pname": a.name, "qty": i2.quantity, "amount": i2.price, "id": i2.id}
            data.append(row)
        elif i2.type == "RAM":
            a = Ram.objects.get(id=i2.particularid)
            row = {"pname": a.name, "qty": i2.quantity, "amount": i2.price, "id": i2.id}
            data.append(row)

        elif i2.type == "PROCESSOR_assm":
            a = Processor.objects.get(id=i2.particularid)
            row = {"pname": a.NAME, "qty": i2.quantity, "amount": i2.price, "id": i2.id}
            data.append(row)
        elif i2.type == "PROCESSOR":
            a = Processor.objects.get(id=i2.particularid)
            row = {"pname": a.NAME, "qty": i2.quantity, "amount": i2.price, "id": i2.id}
            data.append(row)

        elif i2.type == "MOTHERBOARD_assm":
            a = Motherboard.objects.get(id=i2.particularid)
            row = {"pname": a.motherboardname, "qty": i2.quantity, "amount": i2.price, "id": i2.id}
            data.append(row)
        elif i2.type == "MOTHERBOARD":
            a = Motherboard.objects.get(id=i2.particularid)
            row = {"pname": a.motherboardname, "qty": i2.quantity, "amount": i2.price, "id": i2.id}
            data.append(row)

        elif i2.type == "CABINET_assm":
            a = Cabinet.objects.get(id=i2.particularid)
            row = {"pname": a.name, "qty": i2.quantity, "amount": i2.price, "id": i2.id}
            data.append(row)
        elif i2.type == "CABINET":
            a = Cabinet.objects.get(id=i2.particularid)
            row = {"pname": a.name, "qty": i2.quantity, "amount": i2.price, "id": i2.id}
            data.append(row)

        elif i2.type == "STORAGE_assm":
            a = Storage.objects.get(id=i2.particularid)
            row = {"pname": a.name, "qty": i2.quantity, "amount": i2.price, "id": i2.id}
            data.append(row)
        elif i2.type == "STORAGE":
            a = Storage.objects.get(id=i2.particularid)
            row = {"pname": a.name, "qty": i2.quantity, "amount": i2.price, "id": i2.id}
            data.append(row)

        elif i2.type == "GRAPHICSCARD_assm":
            a = Graphicscard.objects.get(id=i2.particularid)
            row = {"pname": a.name, "qty": i2.quantity, "amount": i2.price, "id": i2.id}
            data.append(row)
        elif i2.type == "GRAPHICSCARD":
            a = Graphicscard.objects.get(id=i2.particularid)
            row = {"pname": a.name, "qty": i2.quantity, "amount": i2.price, "id": i2.id}
            data.append(row)

        elif i2.type == "SMPS_assm":
            a = Smps.objects.get(id=i2.particularid)
            row = {"pname": a.name, "qty": i2.quantity, "amount": i2.price, "id": i2.id}
            data.append(row)
        elif i2.type == "SMPS":
            a = Smps.objects.get(id=i2.particularid)
            row = {"pname": a.name, "qty": i2.quantity, "amount": i2.price, "id": i2.id}
            data.append(row)

        elif i2.type == "MONITOR_assm":
            a = Monitor.objects.get(id=i2.particularid)
            row = {"pname": a.name, "qty": i2.quantity, "amount": i2.price, "id": i2.id}
            data.append(row)
        elif i2.type == "MONITOR":
            a = Monitor.objects.get(id=i2.particularid)
            row = {"pname": a.name, "qty": i2.quantity, "amount": i2.price, "id": i2.id}
            data.append(row)


    return render(request,'user/view_cart.html',{'data':data,"amount":totalamount})


def user_bill(request):
    ob=Register.objects.get(LOGIN=request.session["lid"])
    obj = Cart.objects.filter(USERID__LOGIN=request.session["lid"])
    totalamount = 0
    for i in obj:
        totalamount = totalamount + int(i.price)
    totalamount_serv = totalamount + 2500
    data = []
    assemble_data = []
    for i2 in obj:
        if i2.type == "COOLER_assm":
            a = Cooler.objects.get(id=i2.particularid)
            row = {'particularid':i2.particularid,'type':i2.type,'unitprice':a.price,"pname": a.name, "qty": i2.quantity, "amount": i2.price, "id": i2.id}
            assemble_data.append(row)
        elif i2.type == "COOLER":
            a = Cooler.objects.get(id=i2.particularid)
            row = {'particularid':i2.particularid,'type':i2.type,'unitprice':a.price,"pname": a.name, "qty": i2.quantity, "amount": i2.price, "id": i2.id}
            data.append(row)

        elif i2.type == "RAM_assm":
            a = Ram.objects.get(id=i2.particularid)
            row = {'particularid':i2.particularid,'type':i2.type,'unitprice':a.price,"pname": a.name, "qty": i2.quantity, "amount": i2.price, "id": i2.id}
            assemble_data.append(row)
        elif i2.type == "RAM":
            a = Ram.objects.get(id=i2.particularid)
            row = {'particularid':i2.particularid,'type':i2.type,'unitprice':a.price,"pname": a.name, "qty": i2.quantity, "amount": i2.price, "id": i2.id}
            data.append(row)

        elif i2.type == "PROCESSOR_assm":
            a = Processor.objects.get(id=i2.particularid)
            row = {'particularid':i2.particularid,'type':i2.type,'unitprice':a.price,"pname": a.NAME, "qty": i2.quantity, "amount": i2.price, "id": i2.id}
            assemble_data.append(row)
        elif i2.type == "PROCESSOR":
            a = Processor.objects.get(id=i2.particularid)
            row = {'particularid':i2.particularid,'type':i2.type,'unitprice':a.price,"pname": a.NAME, "qty": i2.quantity, "amount": i2.price, "id": i2.id}
            data.append(row)

        elif i2.type == "MOTHERBOARD_assm":
            a = Motherboard.objects.get(id=i2.particularid)
            row = {'particularid':i2.particularid,'type':i2.type,'unitprice':a.price,"pname": a.motherboardname, "qty": i2.quantity, "amount": i2.price, "id": i2.id}
            assemble_data.append(row)
        elif i2.type == "MOTHERBOARD":
            a = Motherboard.objects.get(id=i2.particularid)
            row = {'particularid':i2.particularid,'type':i2.type,'unitprice':a.price,"pname": a.motherboardname, "qty": i2.quantity, "amount": i2.price, "id": i2.id}
            data.append(row)

        elif i2.type == "CABINET_assm":
            a = Cabinet.objects.get(id=i2.particularid)
            row = {'particularid':i2.particularid,'type':i2.type,'unitprice':a.price,"pname": a.name, "qty": i2.quantity, "amount": i2.price, "id": i2.id}
            assemble_data.append(row)
        elif i2.type == "CABINET":
            a = Cabinet.objects.get(id=i2.particularid)
            row = {'particularid':i2.particularid,'type':i2.type,'unitprice':a.price,"pname": a.name, "qty": i2.quantity, "amount": i2.price, "id": i2.id}
            data.append(row)

        elif i2.type == "STORAGE_assm":
            a = Storage.objects.get(id=i2.particularid)
            row = {'particularid':i2.particularid,'type':i2.type,'unitprice':a.price,"pname": a.name, "qty": i2.quantity, "amount": i2.price, "id": i2.id}
            assemble_data.append(row)
        elif i2.type == "STORAGE":
            a = Storage.objects.get(id=i2.particularid)
            row = {'particularid':i2.particularid,'type':i2.type,'unitprice':a.price,"pname": a.name, "qty": i2.quantity, "amount": i2.price, "id": i2.id}
            data.append(row)

        elif i2.type == "GRAPHICSCARD_assm":
            a = Graphicscard.objects.get(id=i2.particularid)
            row = {'particularid':i2.particularid,'type':i2.type,'unitprice':a.price,"pname": a.name, "qty": i2.quantity, "amount": i2.price, "id": i2.id}
            assemble_data.append(row)
        elif i2.type == "GRAPHICSCARD":
            a = Graphicscard.objects.get(id=i2.particularid)
            row = {'particularid':i2.particularid,'type':i2.type,'unitprice':a.price,"pname": a.name, "qty": i2.quantity, "amount": i2.price, "id": i2.id}
            data.append(row)

        elif i2.type == "SMPS_assm":
            a = Smps.objects.get(id=i2.particularid)
            row = {'particularid':i2.particularid,'type':i2.type,'unitprice':a.price,"pname": a.name, "qty": i2.quantity, "amount": i2.price, "id": i2.id}
            assemble_data.append(row)
        elif i2.type == "SMPS":
            a = Smps.objects.get(id=i2.particularid)
            row = {'particularid':i2.particularid,'type':i2.type,'unitprice':a.price,"pname": a.name, "qty": i2.quantity, "amount": i2.price, "id": i2.id}
            data.append(row)

        elif i2.type == "MONITOR_assm":
            a = Monitor.objects.get(id=i2.particularid)
            row = {'particularid':i2.particularid,'type':i2.type,'unitprice':a.price,"pname": a.name, "qty": i2.quantity, "amount": i2.price, "id": i2.id}
            assemble_data.append(row)
        elif i2.type == "MONITOR":
            a = Monitor.objects.get(id=i2.particularid)
            row = {'particularid':i2.particularid,'type':i2.type,'unitprice':a.price,"pname": a.name, "qty": i2.quantity, "amount": i2.price, "id": i2.id}
            data.append(row)
        else:
            pass
    request.session["assem"]=assemble_data
    request.session["data"]=data

    return render(request,'user/user_bill.html',{"user":ob,"data":data,"assem":assemble_data,"total":totalamount,"with_service":totalamount_serv})


def placeorder(request):
    obj = Cart.objects.filter(USERID__LOGIN=request.session["lid"])
    totalamount = sum(int(i.price) for i in obj)  # Calculate total amount from the cart
    totalamount_serv = totalamount + 2500

    assemble = request.session.get("assem", [])
    print(type(assemble), assemble, "----------------")

    normalpro = request.session.get("data", [])
    print(type(normalpro), normalpro, "----------------mmmmmm")

    # Initialize variables
    ass_amount = 0
    ob = None  # Initialize ob to None to avoid UnboundLocalError

    # Process assembled products
    if len(assemble) > 0:
        for i in assemble:
            ass_amount += int(i["amount"])

        ob = Order_main()  # Initialize ob for assembled order
        ob.ammount = ass_amount
        ob.date = datetime.now().date()
        ob.status = "ordered"
        ob.USERID = Register.objects.get(LOGIN=request.session["lid"])
        ob.type = "assemble"
        ob.save()  # Save the assembled order

        for ii in assemble:
            obb = Order_sub()  # Create a new Order_sub instance
            obb.quantity = ii["qty"]
            obb.type = ii["type"]
            obb.price = ii["amount"]
            obb.particularid = ii["particularid"]
            obb.ORDERMAIN_ID = ob  # Link to the assembled order
            obb.save()  # Save the Order_sub instance

    # Process normal products
    if len(normalpro) > 0:
        data_amount = sum(int(i["amount"]) for i in normalpro)

        ob1 = Order_main()  # Initialize ob1 for normal order
        ob1.ammount = data_amount
        ob1.date = datetime.now().date()
        ob1.status = "ordered"
        ob1.USERID = Register.objects.get(LOGIN=request.session["lid"])
        ob1.type = "normal"
        ob1.save()  # Save the normal order

        for ii in normalpro:
            obb1 = Order_sub()  # Create a new Order_sub instance for normal products
            obb1.quantity = ii["qty"]
            obb1.type = ii["type"]
            obb1.price = ii["amount"]
            obb1.particularid = ii["particularid"]
            obb1.ORDERMAIN_ID = ob1  # Link to the normal order
            obb1.save()  # Save the Order_sub instance

    # Clear the cart after placing the order
    Cart.objects.filter(USERID__LOGIN=request.session["lid"]).delete()

    return HttpResponse("<script>alert('Order placed successfully'); window.location='/myapp/user_home/'</script>")


def view_order_status(request):
    # Fetch all Order_sub entries related to the logged-in user
    a = Order_sub.objects.filter(ORDERMAIN_ID__USERID__LOGIN_id=request.session['lid'])
    l = []

    for i in a:
        # Get the associated Order_main object
        order_main = i.ORDERMAIN_ID

        # Initialize assigned status as None or any default value
        assigned_status = None

        # Check if there's an assignment related to the order
        try:
            assignment = Assign.objects.get(ORDERMAIN_ID=order_main)
            assigned_status = assignment.status  # Get the assigned status
        except Assign.DoesNotExist:
            assigned_status = "Not Assigned"  # Default value if not assigned

        # Determine the name based on the product type
        if i.type in ["MOTHERBOARD", "MOTHERBOARD_assm"]:
            name = Motherboard.objects.get(id=i.particularid).motherboardname
        elif i.type in ["RAM", "RAM_assm"]:
            name = Ram.objects.get(id=int(i.particularid)).name
        elif i.type in ["PROCESSOR", "PROCESSOR_assm"]:
            name = Processor.objects.get(id=int(i.particularid)).NAME
        elif i.type in ["STORAGE", "STORAGE_assm"]:
            name = Storage.objects.get(id=int(i.particularid)).name
        elif i.type in ["GRAPHICSCARD", "GRAPHICSCARD_assm"]:
            name = Graphicscard.objects.get(id=int(i.particularid)).name
        elif i.type in ["SMPS", "SMPS_assm"]:
            name = Smps.objects.get(id=int(i.particularid)).name
        elif i.type in ["CABINET", "CABINET_assm"]:
            name = Cabinet.objects.get(id=int(i.particularid)).name
        elif i.type in ["MONITOR", "MONITOR_assm"]:
            name = Monitor.objects.get(id=int(i.particularid)).name
        elif i.type in ["COOLER", "COOLER_assm"]:
            name = Cooler.objects.get(id=int(i.particularid)).name
        else:
            name = "Unknown Product"

        # Append the data to the list
        l.append({
            'id': i.id,
            'quantity': i.quantity,
            'price': i.price,
            'particularid': i.particularid,
            'omid': order_main.id,
            'date': order_main.date,
            'ammount': i.price,
            'status': order_main.status,
            'assigned_status': assigned_status,  # Include assigned status
            'name': name
        })

    return render(request, 'user/view_order_status.html', {'data': l})


# def sa(request):
#     obj=Order_main.objects.all()
#     context={
#         'a':obj
#     }
#     return render(request,'user/view_order_status.html',context)

def view_user_profile(request):
    res=Register.objects.get(LOGIN__id=request.session['lid'])
    return render(request,'user/view_user_profile.html',{'data':res})

def deliveryboy_home(request):
    return render(request,'deliveryboy/deliveryboy_home.html')


def user_buy_assembleproduct_adv(request):
    m = Motherboard.objects.filter(price__gte=30000, price__lte=60000)
    return render(request,'user/user_buy_assembleproduct_adv.html',{'data':m})
def addtocart_assemblemotherboard_adv(request):

    pid=request.POST['pid']

    request.session["mid"]=pid
    ob = Motherboard.objects.get(id=pid)
    amt = 1 * int(ob.price)

    ca = Cart()
    ca.price = amt
    ca.quantity=1
    ca.particularid=pid
    ca.type='MOTHERBOARD_assm'
    ca.USERID = Register.objects.get(LOGIN_id=request.session['lid'])
    ca.save()

    return HttpResponse("<script>alert('Motherboard Added succesfully'); window.location='/myapp/user_assemble_ram_adv/'</script>")

def user_assemble_ram_adv(request):
    m=Ram.objects.filter(Motherboard_id=request.session["mid"])
    return render(request,'user/user_assemble_ram_adv.html',{'data':m})
def addtocart_assembleram_adv(request):

    pid=request.POST['pid']

    ob = Ram.objects.get(id=pid)
    amt = 1 * int(ob.price)

    ca = Cart()
    ca.price = amt
    ca.quantity = 1
    ca.particularid = pid
    ca.USERID = Register.objects.get(LOGIN_id=request.session['lid'])
    ca.type = 'RAM_assm'
    ca.save()


    return HttpResponse("<script>alert('Ram Added succesfully'); window.location='/myapp/user_assemble_processor_adv/'</script>")

def user_assemble_processor_adv(request):
    m=Processor.objects.filter(Motherboard_id=request.session["mid"])
    return render(request,'user/user_assemble_processor_adv.html',{'data':m})
def addtocart_assembleprocessor_adv(request):

    pid=request.POST['pid']

    ob = Processor.objects.get(id=pid)
    amt = 1 * int(ob.price)

    ca = Cart()
    ca.price = amt
    ca.quantity=1
    ca.particularid=pid
    ca.type='PROCESSOR_assm'
    ca.USERID = Register.objects.get(LOGIN_id=request.session['lid'])
    ca.save()

    return HttpResponse("<script>alert('Processor Added succesfully'); window.location='/myapp/user_assemble_storage_adv/'</script>")

def user_assemble_storage_adv(request):
    m=Storage.objects.filter(Motherboard_id=request.session["mid"])
    return render(request,'user/user_assemble_storage_adv.html',{'data':m})
def addtocart_assemblestorage_adv(request):

    pid=request.POST['pid']

    ob = Storage.objects.get(id=pid)
    amt = 1 * int(ob.price)

    ca = Cart()
    ca.price = amt
    ca.quantity=1
    ca.particularid=pid
    ca.type='STORAGE_assm'
    ca.USERID = Register.objects.get(LOGIN_id=request.session['lid'])
    ca.save()

    return HttpResponse("<script>alert('Strorage Added succesfully'); window.location='/myapp/user_assemble_graphics_adv/'</script>")

def user_assemble_graphics_adv(request):
    m=Graphicscard.objects.filter(Motherboard_id=request.session["mid"])
    return render(request,'user/user_assemble_graphics_adv.html',{'data':m})
def addtocart_assemblegraphics_adv(request):

    pid=request.POST['pid']

    ob = Graphicscard.objects.get(id=pid)
    amt = 1 * int(ob.price)

    ca = Cart()
    ca.price = amt
    ca.quantity=1
    ca.particularid=pid
    ca.type='GRAPHICSCARD_assm'
    ca.USERID = Register.objects.get(LOGIN_id=request.session['lid'])
    ca.save()

    return HttpResponse("<script>alert('Graphicscard Added succesfully'); window.location='/myapp/user_assemble_smps_adv/'</script>")

def user_assemble_smps_adv(request):
    m=Smps.objects.filter(Motherboard_id=request.session["mid"])
    return render(request,'user/user_assemble_smps_adv.html',{'data':m})
def aaddtocart_assemblesmps_adv(request):

    pid=request.POST['pid']

    ob = Smps.objects.get(id=pid)
    amt = 1 * int(ob.price)

    ca = Cart()
    ca.price = amt
    ca.quantity=1
    ca.particularid=pid
    ca.type='SMPS_assm'
    ca.USERID = Register.objects.get(LOGIN_id=request.session['lid'])
    ca.save()

    return HttpResponse("<script>alert('Smps Added succesfully'); window.location='/myapp/user_assemble_cabinet_adv/'</script>")


def user_assemble_cabinet_adv(request):
    m=Cabinet.objects.filter(Motherboard_id=request.session["mid"])
    return render(request,'user/user_assemble_cabinet_adv.html',{'data':m})
def addtocart_assemble_cabinet_adv(request):

    pid=request.POST['pid']

    ob = Cabinet.objects.get(id=pid)
    amt = 1 * int(ob.price)

    ca = Cart()
    ca.price = amt
    ca.quantity=1
    ca.particularid=pid
    ca.type='CABINET_assm'
    ca.USERID = Register.objects.get(LOGIN_id=request.session['lid'])
    ca.save()

    return HttpResponse("<script>alert('Cabnet Added succesfully'); window.location='/myapp/user_assemble_monitor_adv/'</script>")

def user_assemble_monitor_adv(request):
    m=Monitor.objects.filter(Motherboard_id=request.session["mid"])
    return render(request,'user/user_assemble_monitor_adv.html',{'data':m})
def addtocart_assemble_monitor_adv(request):

    pid=request.POST['pid']

    ob = Monitor.objects.get(id=pid)
    amt = 1 * int(ob.price)

    ca = Cart()
    ca.price = amt
    ca.quantity=1
    ca.particularid=pid
    ca.type='MONITOR_assm'
    ca.USERID = Register.objects.get(LOGIN_id=request.session['lid'])
    ca.save()

    return HttpResponse("<script>alert('Monitor Added succesfully'); window.location='/myapp/user_assemble_cooler_adv/'</script>")

def user_assemble_cooler_adv(request):
    m=Cooler.objects.all()
    return render(request,'user/user_assemble_cooler_adv.html',{'data':m})
def addtocart_assemble_cooler_adv(request):

    pid=request.POST['pid']

    ob = Cooler.objects.get(id=pid)
    amt = 1 * int(ob.price)

    ca = Cart()
    ca.price = amt
    ca.quantity=1
    ca.particularid=pid
    ca.type='COOLER_assm'
    ca.USERID = Register.objects.get(LOGIN_id=request.session['lid'])
    ca.save()

    return HttpResponse("<script>alert('Cooler Added succesfully'); window.location='/myapp/view_cart/'</script>")


# def user_order(request,id):
#     a=Cart.objects.get(id=id)
#     a=Oder_main()
#     a.USERID=Register.objects.get(LOGIN_id=request.session['lid'])
#     a.CART=Cart.objects.get(id=id)
#     a.status='ordered'
#     a.date=datetime.now().today().date()
#     a.ammount=1000
#     a.save()
#     return HttpResponse("<script>alert('Cooler Added succesfully'); window.location='/myapp/select_assemble_or_orderproduct/'</script>")





























