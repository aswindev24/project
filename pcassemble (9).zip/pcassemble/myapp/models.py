from django.db import models

# Create your models here.


class Login(models.Model):
    username=models.CharField(max_length=100)
    password=models.CharField(max_length=100)
    type=models.CharField(max_length=100)

class Category(models.Model):
    categoryname=models.CharField(max_length=100)

class Register(models.Model):
    name=models.CharField(max_length=100)
    dob=models.DateField(auto_now_add=True)
    gender=models.CharField(max_length=100)
    place=models.CharField(max_length=100)
    pin=models.CharField(max_length=100)
    post=models.CharField(max_length=100)
    district=models.CharField(max_length=100)
    phonenumber=models.CharField(max_length=100)
    email=models.CharField(max_length=100)
    LOGIN=models.ForeignKey(Login,on_delete=models.CASCADE)

class Deliveryboy(models.Model):
    name=models.CharField(max_length=100)
    email=models.CharField(max_length=100)
    dob=models.DateField(auto_now_add=True)
    street=models.CharField(max_length=100)
    place=models.CharField(max_length=100)
    post=models.CharField(max_length=100)
    district=models.CharField(max_length=100)
    pincode=models.CharField(max_length=100)
    LOGIN = models.ForeignKey(Login, on_delete=models.CASCADE)

class Motherboard(models.Model):
    photo=models.CharField(max_length=100)
    details=models.CharField(max_length=100)
    price=models.CharField(max_length=100)
    motherboardname=models.CharField(max_length=100)
    CATEGORY=models.ForeignKey(Category,on_delete=models.CASCADE)

class Ram(models.Model):
    Motherboard = models.ForeignKey(Motherboard, on_delete=models.CASCADE)
    photo=models.CharField(max_length=100)
    details=models.CharField(max_length=100)
    price=models.CharField(max_length=100)
    name=models.CharField(max_length=100)
    CATEGORY=models.ForeignKey(Category,on_delete=models.CASCADE)

class Processor(models.Model):
    Motherboard = models.ForeignKey(Motherboard, on_delete=models.CASCADE)
    photo=models.CharField(max_length=100)
    details=models.CharField(max_length=100)
    price=models.CharField(max_length=100)
    NAME=models.CharField(max_length=100)
    CATEGORY=models.ForeignKey(Category,on_delete=models.CASCADE)
#
# class Processor(models.Model):
#     Motherboard = models.ForeignKey(Motherboard, on_delete=models.CASCADE)
#     photo=models.CharField(max_length=100)
#     details=models.CharField(max_length=100)
#     price=models.CharField(max_length=100)
#     name=models.CharField(max_length=100)
#     CATEGORY=models.ForeignKey(Category,on_delete=models.CASCADE)

class Cabinet(models.Model):
    Motherboard = models.ForeignKey(Motherboard, on_delete=models.CASCADE)
    photo=models.CharField(max_length=100)
    details=models.CharField(max_length=100)
    price=models.CharField(max_length=100)
    name=models.CharField(max_length=100)
    CATEGORY=models.ForeignKey(Category,on_delete=models.CASCADE)

class Cooler(models.Model):
    Motherboard = models.ForeignKey(Motherboard, on_delete=models.CASCADE)
    photo=models.CharField(max_length=100)
    details=models.CharField(max_length=100)
    price=models.CharField(max_length=100)
    name=models.CharField(max_length=100)
    CATEGORY=models.ForeignKey(Category,on_delete=models.CASCADE)

class Graphicscard(models.Model):
    Motherboard = models.ForeignKey(Motherboard, on_delete=models.CASCADE)
    photo=models.CharField(max_length=100)
    details=models.CharField(max_length=100)
    price=models.CharField(max_length=100)
    name=models.CharField(max_length=100)
    CATEGORY=models.ForeignKey(Category,on_delete=models.CASCADE)

class Keyboard(models.Model):
    Motherboard = models.ForeignKey(Motherboard, on_delete=models.CASCADE)
    photo=models.CharField(max_length=100)
    details=models.CharField(max_length=100)
    price=models.CharField(max_length=100)
    name=models.CharField(max_length=100)
    CATEGORY=models.ForeignKey(Category,on_delete=models.CASCADE)

class Monitor(models.Model):
    Motherboard = models.ForeignKey(Motherboard, on_delete=models.CASCADE)
    photo=models.CharField(max_length=100)
    details=models.CharField(max_length=100)
    price=models.CharField(max_length=100)
    name=models.CharField(max_length=100)
    CATEGORY=models.ForeignKey(Category,on_delete=models.CASCADE)

class Smps(models.Model):
    Motherboard = models.ForeignKey(Motherboard, on_delete=models.CASCADE)
    photo=models.CharField(max_length=100)
    details=models.CharField(max_length=100)
    price=models.CharField(max_length=100)
    name=models.CharField(max_length=100)

    CATEGORY=models.ForeignKey(Category,on_delete=models.CASCADE)

class Storage(models.Model):
    Motherboard = models.ForeignKey(Motherboard, on_delete=models.CASCADE)
    photo=models.CharField(max_length=100)
    details=models.CharField(max_length=100)
    price=models.CharField(max_length=100)
    name=models.CharField(max_length=100)
    CATEGORY=models.ForeignKey(Category,on_delete=models.CASCADE)

class Shop(models.Model):
    name=models.CharField(max_length=100)
    email=models.CharField(max_length=100)
    number=models.CharField(max_length=100)
    street=models.CharField(max_length=100)
    place=models.CharField(max_length=100)
    post=models.CharField(max_length=100)
    district=models.CharField(max_length=100)
    state=models.CharField(max_length=100)
    pin=models.CharField(max_length=100)
    opentime=models.CharField(max_length=100)
    closetime=models.CharField(max_length=100)

class Cart(models.Model):
    quantity=models.CharField(max_length=100)
    type=models.CharField(max_length=100)
    price = models.CharField(max_length=100)
    particularid=models.CharField(max_length=100)
    USERID = models.ForeignKey(Register, on_delete=models.CASCADE,default="")


class Order_main(models.Model):
    ammount=models.CharField(max_length=100)
    date=models.DateField()
    status=models.CharField(max_length=100)
    USERID=models.ForeignKey(Register,on_delete=models.CASCADE)
    type=models.CharField(max_length=50)

class Assign(models.Model):
    aasigndate=models.DateField()
    ORDERMAIN_ID=models.ForeignKey(Order_main, on_delete=models.CASCADE,default="")
    status = models.CharField(max_length=100)
    DELIVERYBOY_ID=models.ForeignKey(Deliveryboy, on_delete=models.CASCADE,default="")


class Order_sub(models.Model):
    quantity = models.CharField(max_length=100)
    type = models.CharField(max_length=100)
    price = models.CharField(max_length=100)
    particularid = models.CharField(max_length=100)
    ORDERMAIN_ID = models.ForeignKey(Order_main, on_delete=models.CASCADE, default="")